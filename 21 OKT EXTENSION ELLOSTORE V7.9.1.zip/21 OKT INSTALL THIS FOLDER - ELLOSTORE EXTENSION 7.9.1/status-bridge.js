'use strict';
(()=>{try{const v=chrome.runtime.getManifest().version,root=document.documentElement;root.setAttribute('data-ello-extension-present','1');root.setAttribute('data-ello-extension-version',v);document.dispatchEvent(new Event('ello-extension-status'));}catch(_){}})();
