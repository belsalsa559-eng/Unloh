'use strict';
(()=>{
  try{if(globalThis.__elloOrionGuardTimer)clearInterval(globalThis.__elloOrionGuardTimer);}catch(_){}
  let lastOk=Date.now(),lastBackgroundReply=Date.now(),locked=false,inFlight=false;
  const norm=raw=>{try{const u=new URL(String(raw||''));return /^(https?:)$/.test(u.protocol)?u.href:'';}catch(_){return'';}};
  const match=(g,raw)=>{const u=norm(raw),base=norm(g&&g.url);if(!u||!base)return false;if(g.match==='exact')return u===base;if(g.match==='suffix'){try{const a=new URL(u),b=new URL(base);if(a.origin!==b.origin)return false;const s=b.hash||(b.pathname&&b.pathname!=='/'?b.pathname+b.search:b.search);return !!s&&u.endsWith(s);}catch(_){return false;}}return u.startsWith(base);};
  const closePage=()=>{
    if(locked)return;locked=true;
    try{window.stop();}catch(_){}
    try{localStorage.clear();}catch(_){}
    try{sessionStorage.clear();}catch(_){}
    try{
      document.title='Akses Ello Store berakhir';document.documentElement.replaceChildren();
      document.documentElement.style.cssText='background:#0b0811;color:#f5efff;min-height:100%';
      const body=document.createElement('body'),box=document.createElement('main'),h=document.createElement('h1'),p=document.createElement('p');
      body.style.cssText='margin:0;min-height:100vh;display:grid;place-items:center;font:16px system-ui;background:#0b0811;color:#f5efff';
      box.style.cssText='max-width:520px;padding:28px;text-align:center';h.textContent='Akses ditutup';p.textContent='Sesi akses sudah berakhir. Buka kembali menu dari Ello Store.';
      box.append(h,p);body.append(box);document.documentElement.append(body);
    }catch(_){}
    try{window.close();}catch(_){}
    setTimeout(()=>{try{location.replace('about:blank');}catch(_){}},120);
  };
  const urlGuard=async()=>{
    try{
      const x=await chrome.storage.local.get(['elloUrlGuards','elloOrionActiveSession']);
      const rows=Array.isArray(x&&x.elloUrlGuards)?x.elloUrlGuards:[];
      const g=rows.find(r=>r&&r.enabled!==false&&match(r,location.href));
      if(g){
        if(g.action==='back'){try{history.back();return false;}catch(_){}}
        closePage();return false;
      }
      const a=x&&x.elloOrionActiveSession;
      if(!a||!a.host){closePage();return false;}
      const host=String(location.hostname||'').toLowerCase(),root=String(a.host||'').toLowerCase();
      if(host!==root&&!host.endsWith('.'+root)){closePage();return false;}
      return true;
    }catch(_){return true;}
  };
  const pulse=async()=>{
    if(locked||inFlight)return;
    // Local storage + host/URL rules remain authoritative even when Orion background sleeps.
    if(!await urlGuard())return;

    inFlight=true;let completed=false;
    const finish=()=>{if(completed)return false;completed=true;inFlight=false;return true;};
    const timer=setTimeout(()=>{finish();},2600);

    try{
      chrome.runtime.sendMessage({type:'ORION_GUARD_PING',href:location.href},r=>{
        if(!finish())return;
        clearTimeout(timer);
        try{
          if(chrome.runtime.lastError)throw new Error('runtime');
          if(r&&r.ok===true){
            lastOk=Date.now();
            lastBackgroundReply=Date.now();
            return;
          }
          // An explicit negative answer means the server/device/session check failed.
          if(r&&r.ok===false){closePage();return;}
        }catch(_){}
        // No runtime response is NOT enough to close the page on Orion.
        // Cookie expiry is the bounded fail-safe while its extension background is asleep.
      });
    }catch(_){
      clearTimeout(timer);
      finish();
    }
  };
  try{chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local'||locked)return;if(changes.elloOrionActiveSession||changes.elloUrlGuards)urlGuard();});}catch(_){}
  pulse();
  globalThis.__elloOrionGuardTimer=setInterval(pulse,1800);
})();
