// R6.14.2AI - panel proteksi hanya muncul saat ekstensi lain TERDETEKSI aktif.
// Pengecekan lokal melalui chrome.management; tidak memanggil Firebase/Cloudflare.
// Jika API tidak tersedia/gagal, tampilkan fallback manual (status tidak diketahui).
// Semua pemeriksaan dan aksi keamanan pada background.js tetap utuh.
(() => {
  'use strict';
  const byId = id => document.getElementById(id);
  const panel = byId('extensionControlPanel');
  if (!panel) return;
  const status = byId('extensionControlStatus');
  const names = byId('extensionControlNames');
  const agree = byId('extensionControlAgree');
  const disable = byId('extensionControlDisable');
  const manual = byId('extensionControlManual');
  const instructions = byId('extensionControlInstructions');
  let candidates = [];
  let supported = false;
  let working = false;
  let loggedIn = false;
  let requestNumber = 0;
  let pollTimer = null;
  let eventTimer = null;

  // Tidak menampilkan panel pada keadaan awal, sampai hasil deteksi tersedia.
  panel.hidden = true;

  function manualGuidance() {
    const ua = String(navigator.userAgent || '');
    if (globalThis.KAGI || /Orion/i.test(ua)) return 'Orion: buka Settings/Pengaturan → Extensions, lalu nonaktifkan ekstensi lain. Jika menggunakan Compatibility Mode, periksa juga ekstensi yang aktif di sana.';
    if (/Edg\//.test(ua)) return 'Microsoft Edge: buka edge://extensions di bilah alamat, lalu matikan ekstensi lain satu per satu. Setelah itu buka kembali Ello Store.';
    if (/Quetta/i.test(ua)) return 'Quetta: buka Menu → Extensions/Ekstensi → Installed, kemudian nonaktifkan ekstensi lain. Fitur otomatis hanya tersedia jika Quetta mendukung API pengelolaan ekstensi.';
    return 'Google Chrome: buka chrome://extensions di bilah alamat, lalu matikan ekstensi lain satu per satu. Setelah itu buka kembali Ello Store.';
  }
  function showManual() {
    instructions.hidden = false;
    instructions.textContent = manualGuidance();
  }
  manual.addEventListener('click', () => {
    instructions.hidden ? showManual() : instructions.hidden = true;
  });
  function syncButton() {
    disable.disabled = working || !supported || !agree.checked || candidates.length === 0;
  }
  agree.addEventListener('change', syncButton);

  function getAll() {
    return new Promise((resolve, reject) => {
      let settled = false;
      const timer = setTimeout(() => finish(null, new Error('API management tidak merespons.')), 4000);
      const finish = (value, error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        error ? reject(error) : resolve(value);
      };
      try {
        // Beberapa browser memakai callback, sebagian WebExtensions juga memakai Promise.
        const result = chrome.management.getAll(items => {
          const err = chrome.runtime && chrome.runtime.lastError;
          finish(items || [], err ? new Error(err.message || 'Akses pengelolaan ditolak.') : null);
        });
        if (result && typeof result.then === 'function') {
          result.then(items => finish(items || [], null), err => finish(null, err));
        }
      } catch (err) { finish(null, err); }
    });
  }
  function resetPanel() {
    candidates = [];
    names.replaceChildren();
    names.hidden = true;
    instructions.hidden = true;
    agree.checked = false;
    panel.hidden = true;
    syncButton();
  }
  function manualFallback(message) {
    // Tidak menyatakan aman bila browser tidak dapat memeriksa ekstensi lain.
    supported = false;
    candidates = [];
    names.replaceChildren();
    names.hidden = true;
    status.textContent = message;
    panel.hidden = false;
    showManual();
    syncButton();
  }
  async function refresh() {
    if (!loggedIn || working) return;
    const id = ++requestNumber;
    supported = !!(globalThis.chrome && chrome.management &&
      typeof chrome.management.getAll === 'function' &&
      typeof chrome.management.setEnabled === 'function');
    if (!supported) {
      manualFallback('Browser tidak mendukung pemeriksaan ekstensi otomatis. Periksa ekstensi lain lewat Cara manual.');
      return;
    }
    try {
      const list = await getAll();
      if (id !== requestNumber || !loggedIn || working) return;
      const ownId = chrome.runtime && chrome.runtime.id;
      const other = list.filter(x => x && x.id !== ownId && x.type === 'extension' && x.enabled === true);
      if (!other.length) {
        // Otomatis hilang setelah semua ekstensi lain NONAKTIF, tanpa reload popup.
        resetPanel();
        return;
      }
      panel.hidden = false;
      candidates = other.filter(x => x.mayDisable !== false)
        .map(x => ({ id:x.id, name:String(x.name || 'Ekstensi lain') }));
      const locked = other.length - candidates.length;
      status.textContent = `${other.length} ekstensi lain aktif${locked ? `; ${locked} tidak boleh dimatikan melalui API browser` : ''}.`;
      names.replaceChildren();
      const listNode = document.createElement('ul');
      for (const item of other) {
        const li = document.createElement('li');
        li.textContent = String(item.name || 'Ekstensi tanpa nama') + (item.mayDisable === false ? ' — dikelola browser' : '');
        listNode.append(li);
      }
      names.append(listNode);
      names.hidden = false;
      if (locked) showManual();
      else instructions.hidden = true;
    } catch (err) {
      if (id !== requestNumber || !loggedIn || working) return;
      manualFallback('Pemeriksaan ekstensi gagal. Gunakan Cara manual untuk memastikan tidak ada ekstensi lain yang aktif.');
    }
    syncButton();
  }

  // Tombol tetap membutuhkan klik dan persetujuan pengguna secara langsung.
  function setDisabledOnClick(id) {
    return new Promise(resolve => {
      let settled = false;
      const finish = value => { if (!settled) { settled = true; resolve(value); } };
      try {
        const result = chrome.management.setEnabled(id, false, () => {
          const err = chrome.runtime && chrome.runtime.lastError;
          finish(err ? { ok:false, reason:err.message || 'Ditolak oleh browser' } : { ok:true });
        });
        if (result && typeof result.then === 'function') {
          result.then(() => finish({ok:true}), e => finish({ok:false, reason:String(e && e.message || e)}));
        }
      } catch (e) { finish({ok:false, reason:String(e && e.message || e)}); }
    });
  }
  disable.addEventListener('click', () => {
    if (working || !loggedIn || !supported || !agree.checked || !candidates.length) return;
    working = true;
    ++requestNumber; // hasil refresh sebelumnya tidak boleh menimpa hasil penonaktifan
    syncButton();
    const targets = candidates.slice();
    status.textContent = 'Meminta browser menonaktifkan ekstensi lain…';
    const jobs = targets.map(item => setDisabledOnClick(item.id));
    Promise.all(jobs).then(async results => {
      const ok = results.filter(x => x.ok).length;
      const failed = results.length - ok;
      working = false;
      if (!loggedIn) return;
      await refresh(); // hasil getAll menentukan apakah panel perlu langsung menghilang
      if (!panel.hidden && failed) {
        showManual();
        status.textContent += ' Beberapa ekstensi gagal dinonaktifkan. Gunakan Cara manual.';
      }
    }).catch(() => {
      working = false;
      if (!loggedIn) return;
      manualFallback('Gagal menonaktifkan ekstensi. Periksa kembali melalui Cara manual.');
    });
  });

  function requestRefreshSoon() {
    if (!loggedIn || working || eventTimer !== null) return;
    eventTimer = setTimeout(() => {
      eventTimer = null;
      refresh();
    }, 150);
  }
  // Event lokal management: panel muncul/hilang segera ketika status ekstensi berubah.
  // Dipasang sekali saja, tidak menyentuh background.js maupun kebijakan cookie.
  const management = globalThis.chrome && chrome.management;
  if (management) {
    for (const eventName of ['onEnabled', 'onDisabled', 'onInstalled', 'onUninstalled']) {
      const ev = management[eventName];
      if (ev && typeof ev.addListener === 'function') {
        try { ev.addListener(requestRefreshSoon); } catch (_) { /* polling tetap tersedia */ }
      }
    }
  }
  function stopWatching() {
    if (pollTimer !== null) { clearInterval(pollTimer); pollTimer = null; }
    if (eventTimer !== null) { clearTimeout(eventTimer); eventTimer = null; }
  }
  globalThis.ElloExtensionControl = {
    show(isLoggedIn) {
      loggedIn = !!isLoggedIn;
      ++requestNumber; // batalkan respons lambat ketika pengguna logout/berganti status
      if (!loggedIn) {
        stopWatching();
        resetPanel();
        return;
      }
      // Panel tetap tersembunyi sampai deteksi menemukan ekstensi lain aktif.
      refresh();
      if (pollTimer === null) {
        // Hanya selagi popup terbuka; tidak melakukan koneksi jaringan.
        pollTimer = setInterval(() => { if (loggedIn && !working) refresh(); }, 5000);
      }
    }
  };
})();
