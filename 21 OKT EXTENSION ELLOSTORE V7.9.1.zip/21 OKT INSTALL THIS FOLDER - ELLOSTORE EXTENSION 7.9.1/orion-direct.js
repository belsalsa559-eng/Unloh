'use strict';
(function(g){
  if(!g.chrome||!g.ElloCookies||!g.ElloWebSession||!g.ELLO_CONFIG)return;

  const SITE='https://ellostoreapk.com/';
  const ACTIVE='elloOrionActiveSession';
  const PENDING='elloOrionPendingSession';
  const REGISTRY='elloCookieLeaseRegistry';
  const TRACE='elloOrionDirectTrace';
  const LEASE_SECONDS=90;
  const manifest=chrome.runtime.getManifest();
  const version=String(manifest&&manifest.version||'7.9.1');

  function versionCode(v){
    const p=String(v||'').replace(/^v/i,'').split('.').slice(0,3).map(x=>parseInt(x,10)||0);
    return (p[0]||0)*10000+(p[1]||0)*100+(p[2]||0);
  }
  const vcode=versionCode(version);

  function bound(p,ms=1400,fallback=null){
    return Promise.race([
      Promise.resolve(p).catch(()=>fallback),
      new Promise(resolve=>setTimeout(()=>resolve(fallback),Math.max(100,Number(ms)||1400)))
    ]);
  }
  function wait(ms){return new Promise(r=>setTimeout(r,ms));}

  async function trace(step,detail=''){
    try{
      const x=await bound(chrome.storage.local.get(TRACE),350,{}),rows=Array.isArray(x&&x[TRACE])?x[TRACE]:[];
      rows.push({at:Date.now(),step:String(step).slice(0,64),detail:String(detail||'').slice(0,180)});
      while(rows.length>30)rows.shift();
      await bound(chrome.storage.local.set({[TRACE]:rows}),350,null);
    }catch(_){}
  }

  async function getCookie(name){
    return await bound(chrome.cookies.get({url:SITE,name}),1000,null);
  }

  async function readSession(){
    const n=ElloWebSession.names;
    const [a,b,d,r]=await Promise.all([
      getCookie(n.id),getCookie(n.refresh),getCookie(n.device),getCookie(n.remember)
    ]);
    if(!a||!b)throw new Error('Sesi website tidak ditemukan. Masuk kembali melalui website.');
    const s=ElloWebSession.fromTokens(
      decodeURIComponent(a.value),
      decodeURIComponent(b.value),
      d?decodeURIComponent(d.value):'',
      !!(r&&decodeURIComponent(r.value)==='1')
    );
    if(!s||!s.uid||!s.deviceId)throw new Error('Sesi website tidak lengkap. Tekan Periksa akses lalu coba lagi.');
    return s;
  }

  async function freshToken(session){
    if(session.expiresAt>Date.now()+45000)return session.idToken;
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
    try{
      const url='https://securetoken.googleapis.com/v1/token?key='+encodeURIComponent(ELLO_CONFIG.apiKey);
      const r=await fetch(url,{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'grant_type=refresh_token&refresh_token='+encodeURIComponent(session.refreshToken),
        signal:controller.signal,
        cache:'no-store',
        credentials:'omit'
      });
      let d={};try{d=await r.json();}catch(_){}
      if(!r.ok||!d.id_token)throw new Error('Sesi login perlu diperbarui. Buka website Ello Store lalu coba lagi.');
      return String(d.id_token);
    }catch(e){
      if(e&&e.name==='AbortError')throw new Error('Pemeriksaan sesi melewati batas waktu.');
      throw e;
    }finally{clearTimeout(timer);}
  }

  async function dbRead(path,session){
    const token=await freshToken(session);
    const clean=String(path||'').split('/').filter(Boolean).map(encodeURIComponent).join('/');
    const url=String(ELLO_CONFIG.databaseURL||'').replace(/\/+$/,'')+'/'+
      String(ELLO_CONFIG.root||'').replace(/^\/+|\/+$/g,'')+'/'+clean+'.json?auth='+encodeURIComponent(token);
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),9000);
    try{
      const r=await fetch(url,{
        method:'GET',
        headers:{'Accept':'application/json'},
        signal:controller.signal,
        cache:'no-store',
        credentials:'omit',
        referrerPolicy:'no-referrer'
      });
      let d=null;try{d=await r.json();}catch(_){}
      if(!r.ok){
        const e=new Error(r.status===401||r.status===403
          ?'Akses katalog perlu diperbarui. Tekan Periksa akses lalu coba lagi.'
          :'Data katalog belum dapat dimuat (HTTP '+r.status+').');
        e.status=r.status;
        throw e;
      }
      return d;
    }catch(e){
      if(e&&e.name==='AbortError')throw new Error('Memuat isi katalog melewati batas waktu. Coba lagi.');
      throw e;
    }finally{clearTimeout(timer);}
  }

  async function getItems(menuId){
    menuId=String(menuId||'').trim();
    if(!/^[A-Za-z0-9_-]{1,128}$/.test(menuId))throw new Error('Katalog tidak valid.');
    await trace('items-start',menuId);
    const session=await readSession();

    // Two reads only, both protected by the existing authenticated Firebase Rules:
    // item definitions and current health state for this catalog.
    const [items,health]=await Promise.all([
      dbRead('extension/items/'+menuId,session),
      dbRead('menuHealth/'+menuId,session)
    ]);

    const src=items&&typeof items==='object'&&!Array.isArray(items)?items:{};
    const healthMap=health&&typeof health==='object'&&!Array.isArray(health)?health:{};
    const out={};

    for(const [itemId,it] of Object.entries(src)){
      if(!it||typeof it!=='object'||Array.isArray(it))continue;
      const h=healthMap[itemId],down=!!(h&&h.down===true);
      out[itemId]=Object.assign({},it,{
        temporaryUnavailable:down,
        healthReason:down?String(h.reason||'Sedang diperbaiki Admin.'):''
      });
    }

    await trace('items-ok',menuId+'|'+Object.keys(out).length);
    return out;
  }

  async function requestAccess(menuId,itemId,session){
    const token=await freshToken(session);
    const endpoint=String(ELLO_CONFIG.gatewayURL||'').replace(/\/+$/,'')+'/v1/access';
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),18000);
    try{
      const r=await fetch(endpoint,{
        method:'POST',
        headers:{
          'Authorization':'Bearer '+token,
          'Content-Type':'application/json',
          'Accept':'application/json'
        },
        body:JSON.stringify({
          menuId,itemId,
          deviceId:session.deviceId,
          extensionVersion:version,
          extensionVersionCode:vcode
        }),
        signal:controller.signal,
        cache:'no-store',
        credentials:'omit',
        redirect:'error',
        referrerPolicy:'no-referrer'
      });
      let d={};try{d=await r.json();}catch(_){}
      if(!r.ok||!d||d.ok!==true){
        const e=new Error(String(d&&d.error||('Akses ditolak (HTTP '+r.status+').')));
        e.code=String(d&&d.code||'ACCESS_ERROR');
        throw e;
      }
      return d;
    }catch(e){
      if(e&&e.name==='AbortError')throw new Error('Menyiapkan akses melewati batas waktu. Coba lagi.');
      throw e;
    }finally{clearTimeout(timer);}
  }

  function removeDetails(c){
    const host=String(c&&c.domain||'').replace(/^\./,'');
    const path=String(c&&c.path||'/');
    const q={
      url:(c&&c.secure?'https://':'http://')+host+(path.startsWith('/')?path:'/'+path),
      name:String(c&&c.name||'')
    };
    if(c&&c.storeId)q.storeId=c.storeId;
    if(c&&c.partitionKey)q.partitionKey=c.partitionKey;
    return q;
  }

  async function wipeHost(host){
    try{host=ElloCookies.host(host);}catch(_){return 0;}
    if(host==='ellostoreapk.com'||host.endsWith('.ellostoreapk.com'))return 0;
    let rows=await bound(chrome.cookies.getAll({domain:host}),1200,[]);
    if(!Array.isArray(rows))rows=[];
    let removed=0;
    for(const c of rows){
      try{
        const d=String(c&&c.domain||'').replace(/^\./,'').toLowerCase();
        if(!ElloCookies.inScope(d,host))continue;
        const ok=await bound(chrome.cookies.remove(removeDetails(c)),450,null);
        if(ok)removed++;
      }catch(_){}
    }
    return removed;
  }

  async function sessionStore(){
    if(chrome.storage&&chrome.storage.session&&typeof chrome.storage.session.set==='function')return chrome.storage.session;
    return chrome.storage.local;
  }

  async function clearOldOrion(){
    const x=await bound(chrome.storage.local.get([ACTIVE,PENDING,REGISTRY]),700,{});
    const active=x&&x[ACTIVE],pending=x&&x[PENDING],registry=x&&x[REGISTRY]&&typeof x[REGISTRY]==='object'?x[REGISTRY]:{};
    const hosts=new Set(),tabIds=new Set(),kept={};

    if(active&&active.host)hosts.add(String(active.host));
    if(pending&&pending.host)hosts.add(String(pending.host));
    for(const [k,e] of Object.entries(registry)){
      if(e&&e.orionIos===true){
        if(e.host)hosts.add(String(e.host));
        const tid=Number(k);if(Number.isInteger(tid))tabIds.add(tid);
      }else kept[k]=e;
    }

    await bound(chrome.storage.local.set({[REGISTRY]:kept}),500,null);
    await bound(chrome.storage.local.remove([ACTIVE,PENDING]),500,null);

    const ss=await sessionStore();
    for(const tid of tabIds){
      await bound(ss.remove('elloTabGuard_'+String(tid)),250,null);
      if(ss!==chrome.storage.local)await bound(chrome.storage.local.remove('elloTabGuard_'+String(tid)),250,null);
    }

    // Cookie/security state is removed first. Tab APIs are only cosmetic/best-effort.
    for(const h of hosts)await wipeHost(h);

    // Never let an Orion tab API hold the next menu open.
    for(const tid of tabIds){
      bound(chrome.tabs.remove(tid),350,null).then(async r=>{
        if(!r)await bound(chrome.tabs.update(tid,{url:'about:blank'}),350,null);
      });
    }
    const all=await bound(chrome.tabs.query({}),650,[]);
    if(Array.isArray(all)){
      for(const t of all){
        if(!t||!Number.isInteger(t.id)||tabIds.has(t.id))continue;
        let match=false;
        try{
          const u=new URL(String(t.url||''));
          match=[...hosts].some(h=>u.protocol==='https:'&&ElloCookies.inScope(u.hostname,h));
        }catch(_){}
        if(match)bound(chrome.tabs.remove(t.id),350,null).then(async r=>{
          if(!r)await bound(chrome.tabs.update(t.id,{url:'about:blank'}),350,null);
        });
      }
    }
    return true;
  }

  function cookieRef(c){
    return{
      name:String(c.name||''),
      domain:String(c.domain||''),
      path:String(c.path||'/'),
      storeId:String(c.storeId||''),
      secure:c.secure===true,
      hostOnly:c.hostOnly===true,
      partitionKey:c.partitionKey||null
    };
  }

  async function installCookies(payload,host){
    if(!payload||payload.schemaVersion!==1||!Array.isArray(payload.cookies)||!payload.cookies.length)
      throw new Error('Data akses belum tersedia.');

    const refs=[],ttl=Math.floor(Date.now()/1000)+LEASE_SECONDS;
    for(let i=0;i<payload.cookies.length;i++){
      const raw=ElloCookies.setDetails(payload.cookies[i],host);
      const d=Object.assign({},raw,{expirationDate:ttl});
      const applied=await bound(chrome.cookies.set(d),1000,null);
      if(!applied){
        for(const r of refs){
          const h=String(r.domain||'').replace(/^\./,'');
          const q={url:(r.secure?'https://':'http://')+h+(r.path||'/'),name:r.name};
          if(r.storeId)q.storeId=r.storeId;
          if(r.partitionKey)q.partitionKey=r.partitionKey;
          await bound(chrome.cookies.remove(q),300,null);
        }
        throw new Error('Browser menolak sebagian data akses. Coba izinkan situs lalu ulangi.');
      }
      refs.push(cookieRef(applied));
    }
    return refs;
  }

  async function browserConfig(){
    const url=String(ELLO_CONFIG.databaseURL).replace(/\/$/,'')+'/'+
      String(ELLO_CONFIG.root).replace(/^\/|\/$/g,'')+'/website/browserExtensionConfig.json';
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
    try{
      const r=await fetch(url,{cache:'no-store',signal:controller.signal,credentials:'omit'});
      if(!r.ok)return{};
      return await r.json()||{};
    }catch(_){return{};}finally{clearTimeout(timer);}
  }

  function desktopPatchCode(){
    return `(function(){try{
      var apply=function(){
        var m=document.querySelector('meta[name="viewport"]');
        if(!m){m=document.createElement('meta');m.name='viewport';(document.head||document.documentElement).appendChild(m);}
        m.setAttribute('content','width=1280, initial-scale=0.30, minimum-scale=0.10, maximum-scale=5, user-scalable=yes');
        document.documentElement.style.minWidth='1180px';
        if(document.body)document.body.style.minWidth='1180px';
      };
      apply();
      if(!window.__elloDesktopLayoutObserver&&window.MutationObserver){
        window.__elloDesktopLayoutObserver=new MutationObserver(apply);
        window.__elloDesktopLayoutObserver.observe(document.documentElement,{childList:true,subtree:true});
      }
    }catch(_){}})();`;
  }

  async function injectGuard(tabId,desktopMode){
    for(let i=0;i<3;i++){
      let ok=false;
      if(chrome.scripting&&typeof chrome.scripting.executeScript==='function'){
        ok=!!await bound(
          chrome.scripting.executeScript({target:{tabId},files:['orion-guard.js']}).then(()=>true),
          650,false
        );
      }
      if(!ok&&chrome.tabs&&typeof chrome.tabs.executeScript==='function'){
        ok=!!await bound(
          chrome.tabs.executeScript(tabId,{file:'orion-guard.js',runAt:'document_start'}).then(()=>true),
          650,false
        );
      }
      if(ok){
        if(desktopMode&&chrome.tabs&&typeof chrome.tabs.executeScript==='function'){
          bound(chrome.tabs.executeScript(tabId,{code:desktopPatchCode(),runAt:'document_start'}),500,null);
        }
        return true;
      }
      await wait(160);
    }
    return false;
  }

  async function findTab(url){
    const tabs=await bound(chrome.tabs.query({}),700,[]);
    if(!Array.isArray(tabs))return null;
    return tabs.find(t=>t&&Number.isInteger(t.id)&&String(t.url||'')===String(url||''))||null;
  }

  async function finalizePreparedTab(tabId,url,meta,nonce){
    if(!Number.isInteger(Number(tabId))||Number(tabId)<=0)return false;
    tabId=Number(tabId);
    const now=Date.now(),ownerKey=meta.uid+'|'+meta.deviceId;

    const x=await bound(chrome.storage.local.get(REGISTRY),500,{});
    const reg=x&&x[REGISTRY]&&typeof x[REGISTRY]==='object'?x[REGISTRY]:{};
    reg[String(tabId)]={
      tabId,uid:meta.uid,deviceId:meta.deviceId,ownerKey,
      refs:meta.refs,host:meta.host,menuId:meta.menuId,itemId:meta.itemId,
      orionIos:true,createdAt:now,lastRefreshAt:now,leaseUntil:now+LEASE_SECONDS*1000
    };

    const active={
      tabId,uid:meta.uid,deviceId:meta.deviceId,host:meta.host,
      menuId:meta.menuId,itemId:meta.itemId,nonce,
      createdAt:now,lastOkAt:now
    };

    await bound(chrome.storage.local.set({[REGISTRY]:reg,[ACTIVE]:active}),550,null);
    await bound(chrome.storage.local.remove(PENDING),350,null);

    const token=crypto.randomUUID?crypto.randomUUID():String(now)+Math.random();
    const guardState={
      token,createdAt:now,uid:meta.uid,deviceId:meta.deviceId,ownerKey,
      host:meta.host,menuId:meta.menuId,itemId:meta.itemId,url,
      cookieRefs:meta.refs,desktopMode:meta.desktopMode===true,orionIos:true
    };
    const ss=await sessionStore();
    await bound(ss.set({['elloTabGuard_'+tabId]:guardState}),450,null);
    if(ss!==chrome.storage.local)
      await bound(chrome.storage.local.set({['elloTabGuard_'+tabId]:guardState}),450,null);

    // Best effort only. A failure here must never stop the already-opened target page.
    injectGuard(tabId,meta.desktopMode===true).catch(()=>{});
    return true;
  }

  async function openPreparedTab(url,meta){
    const now=Date.now();
    const nonce=crypto.randomUUID?crypto.randomUUID():String(now)+Math.random();
    const ownerKey=meta.uid+'|'+meta.deviceId;

    // Stage all security metadata BEFORE switching tabs. If Orion destroys the popup
    // during activation, background onCreated/onUpdated can adopt this pending session.
    const pending={
      uid:meta.uid,deviceId:meta.deviceId,ownerKey,
      host:meta.host,menuId:meta.menuId,itemId:meta.itemId,
      refs:meta.refs,url,desktopMode:meta.desktopMode===true,
      nonce,createdAt:now,leaseUntil:now+LEASE_SECONDS*1000
    };
    await bound(chrome.storage.local.set({[PENDING]:pending}),500,null);
    await trace('launch-active',meta.host);

    // IMPORTANT: Orion must receive active:true on the original create call.
    // Creating inactive then tabs.update({active:true}) produced a hidden/background tab.
    let createError=null;
    const createPromise=chrome.tabs.create({url,active:true}).catch(e=>{
      createError=e;
      return null;
    });

    // If Orion returns the tab object before the popup is destroyed, finalize immediately.
    // If the popup disappears first, the already-staged PENDING record is adopted by
    // background tab events when Orion's extension runtime is available.
    const tab=await bound(createPromise,700,'__PENDING__');
    if(tab==='__PENDING__'){
      return{opened:true,tabId:0,pending:true};
    }
    if(!tab||!Number.isInteger(tab.id)){
      await bound(chrome.storage.local.remove(PENDING),300,null);
      throw new Error(createError&&createError.message
        ? String(createError.message)
        : 'Orion tidak dapat membuka tab tujuan.');
    }

    await finalizePreparedTab(tab.id,url,meta,nonce);
    return{opened:true,tabId:tab.id};
  }

  async function runItem(menuId,itemId){
    await trace('start',menuId+'|'+itemId);
    const session=await readSession();
    await trace('session-ok',session.uid);

    // Authoritative validation/quota happens server-side before local state changes.
    const access=await requestAccess(menuId,itemId,session);
    const host=ElloCookies.host(access&&access.host);
    const url=ElloCookies.target(access&&access.url,host);
    await trace('access-ok',host);

    // One global cookie session on Orion. No runtime.sendMessage/background dependency.
    await clearOldOrion();
    await trace('old-cleared',host);

    const refs=await installCookies(access.payload,host);
    await trace('cookies-set',String(refs.length));

    const cfg=await browserConfig();
    const desktopMode=String(cfg&&cfg.mobileDefaultMode||'desktop').toLowerCase()!=='mobile';

    try{
      const result=await openPreparedTab(url,{
        uid:session.uid,deviceId:session.deviceId,host,menuId,itemId,refs,desktopMode
      });
      await trace('opened',String(result.tabId));
      return{
        set:refs.length,
        total:refs.length,
        opened:true,
        remaining:Number.isFinite(Number(access&&access.quota&&access.quota.remaining))?Number(access.quota.remaining):0,
        resetAt:Number.isFinite(Number(access&&access.quota&&access.quota.resetAt))?Number(access.quota.resetAt):0
      };
    }catch(e){
      await wipeHost(host);
      await bound(chrome.storage.local.remove(ACTIVE),350,null);
      await trace('open-failed',String(e&&e.message||e));
      throw e;
    }
  }

  g.ElloOrionDirect={runItem,getItems};
})(globalThis);
