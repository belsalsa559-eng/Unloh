/* The website owns login; the extension reads the two first-party cookies. */
(function(g){'use strict';
const names={id:'__Secure-ello-id-v51',refresh:'__Secure-ello-refresh-v51',device:'__Secure-ello-device-v74',remember:'__Secure-ello-remember-v800'};
function hosted(){return typeof location!=='undefined'&&/^(www\.)?ellostoreapk\.com$/i.test(location.hostname)&&location.protocol==='https:';}
function put(name,value,age){if(!hosted())return;document.cookie=name+'='+encodeURIComponent(value||'')+'; Domain=ellostoreapk.com; Path=/; Max-Age='+age+'; SameSite=Strict; Secure';}
function get(name){if(typeof document==='undefined')return'';const pair=document.cookie.split('; ').find(v=>v.startsWith(name+'='));if(!pair)return'';try{return decodeURIComponent(pair.slice(name.length+1));}catch(_){return'';}}
function publish(s){if(!hosted())return true;if(!s){put(names.id,'',0);put(names.refresh,'',0);put(names.device,'',0);return true;}put(names.id,s.idToken,2592000);put(names.refresh,s.refreshToken,2592000);put(names.device,s.deviceId||'',2592000);return get(names.id)===s.idToken&&get(names.refresh)===s.refreshToken&&get(names.device)===String(s.deviceId||'');}
function fromTokens(idToken,refreshToken,deviceId,remember){if(!idToken||!refreshToken)return null;try{const part=idToken.split('.')[1];const normalized=part.replace(/-/g,'+').replace(/_/g,'/');const data=JSON.parse(atob(normalized.padEnd(Math.ceil(normalized.length/4)*4,'=')));const uid=String(data.user_id||data.sub||'');if(!uid||!Number.isFinite(data.exp))return null;return{uid,email:String(data.email||''),idToken,refreshToken,deviceId:String(deviceId||''),remember:remember===true,expiresAt:data.exp*1000-60000};}catch(_){return null;}}
g.ElloWebSession={names,publish,get,fromTokens,hosted};if(typeof module!=='undefined')module.exports=g.ElloWebSession;
})(globalThis);
