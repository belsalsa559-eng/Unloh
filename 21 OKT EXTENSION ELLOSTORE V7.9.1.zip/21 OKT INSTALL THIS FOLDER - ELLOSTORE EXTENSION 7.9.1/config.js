globalThis.ELLO_CONFIG = {
  "apiKey": "AIzaSyDmanadoenRgt9HRvlSeM8TFDoLhDKzZbA",
  "databaseURL": "https://ellostoreapkcom-default-rtdb.asia-southeast1.firebasedatabase.app",
  "root": "ellostore",
  "website": "https://ellostoreapk.com",
  "gatewayURL": "https://gateway.ellostoreapk.com",
  "paymentNumber": "083165845298",
  "whatsappNumber": "6283165845298",
  "version": "7.9.1"
};

try{Object.freeze(globalThis.ELLO_CONFIG);}catch(_){/* production hardening */}
