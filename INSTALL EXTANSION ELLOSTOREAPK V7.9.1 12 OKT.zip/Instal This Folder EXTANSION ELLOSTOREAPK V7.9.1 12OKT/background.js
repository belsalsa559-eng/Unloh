'use strict';
if(typeof importScripts==='function')importScripts('config.js','firebase.js','cookies.js','web-session.js');

const SITE='https://ellostoreapk.com/';
const cookieStorage={
  get:async()=>{
    const [a,b,d,r]=await Promise.all([
      chrome.cookies.get({url:SITE,name:ElloWebSession.names.id}),
      chrome.cookies.get({url:SITE,name:ElloWebSession.names.refresh}),
      chrome.cookies.get({url:SITE,name:ElloWebSession.names.device}),
      chrome.cookies.get({url:SITE,name:ElloWebSession.names.remember})
    ]);
    if(!a||!b)return null;
    try{return ElloWebSession.fromTokens(
      decodeURIComponent(a.value),
      decodeURIComponent(b.value),
      d?decodeURIComponent(d.value):'',
      !!(r&&decodeURIComponent(r.value)==='1')
    );}catch(_){return null;}
  },
  set:async s=>{
    if(!s){
      await Promise.all([
        chrome.cookies.remove({url:SITE,name:ElloWebSession.names.id}),
        chrome.cookies.remove({url:SITE,name:ElloWebSession.names.refresh}),
        chrome.cookies.remove({url:SITE,name:ElloWebSession.names.device}),
        chrome.cookies.remove({url:SITE,name:ElloWebSession.names.remember})
      ]);
      return;
    }
    const expiry=Math.floor(Date.now()/1000)+2592000,remember=s.remember===true;
    for(const [name,value] of [
      [ElloWebSession.names.refresh,s.refreshToken],
      [ElloWebSession.names.id,s.idToken],
      [ElloWebSession.names.device,s.deviceId||''],
      [ElloWebSession.names.remember,remember?'1':'0']
    ]){
      const details={url:SITE,name,value:encodeURIComponent(value),domain:'ellostoreapk.com',path:'/',secure:true,httpOnly:true,sameSite:'strict'};
      if(remember)details.expirationDate=expiry;
      const c=await chrome.cookies.set(details);
      if(!c)throw new Error('Sesi website tidak dapat diperbarui.');
    }
  }
};
const client=new ElloFirebase.Client(ELLO_CONFIG,cookieStorage);
let initializing,runItemTask=null,runItemKey='',runItemTaskAt=0,deviceId='',releaseCache=null,releaseCacheAt=0;
let orionContextCache={at:0,value:false};
const ORION_CONTEXT_TTL=30000,ORION_COOKIE_LEASE_SECONDS=90,ORION_COOKIE_REFRESH_MS=12000;
const ORION_ACTIVE_SESSION='elloOrionActiveSession';
const ORION_PENDING_SESSION='elloOrionPendingSession';
function orionBound(p,ms=1200,fallback=null){
  return Promise.race([
    Promise.resolve(p).catch(()=>fallback),
    new Promise(resolve=>setTimeout(()=>resolve(fallback),Math.max(100,Number(ms)||1200)))
  ]);
}
const DESKTOP_UA_RULE_BASE=9600000;
const DESKTOP_UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
async function orionIOSHost(force=false){
  const now=Date.now();
  if(!force&&now-orionContextCache.at<ORION_CONTEXT_TTL)return orionContextCache.value;
  let value=false;
  try{
    const ua=String(globalThis.navigator&&navigator.userAgent||'');
    // Orion documents expose KAGI. This avoids depending on the popup having been opened first.
    value=!!globalThis.KAGI&&/iPhone|iPad|iPod|Mobile/i.test(ua);
  }catch(_){}
  if(!value){
    try{
      const x=await chrome.storage.local.get('elloOrionIOSContext'),v=x&&x.elloOrionIOSContext;
      value=!!(v&&v.enabled===true&&Number(v.at||0)>now-7*86400000);
    }catch(_){}
  }
  if(value){try{await chrome.storage.local.set({elloOrionIOSContext:{enabled:true,at:now}});}catch(_){}}
  orionContextCache={at:now,value};
  return value;
}
const LOCAL_VERSION=chrome.runtime.getManifest().version;
function versionParts(v){return String(v||'').replace(/^v/i,'').split('.').slice(0,4).map(x=>parseInt(x,10)||0);}
function versionCode(v){const p=versionParts(v);return (p[0]||0)*10000+(p[1]||0)*100+(p[2]||0);}
const LOCAL_VERSION_CODE=versionCode(LOCAL_VERSION);
function compareVersion(a,b){const x=versionParts(a),y=versionParts(b),n=Math.max(x.length,y.length,3);for(let i=0;i<n;i++){const d=(x[i]||0)-(y[i]||0);if(d)return d>0?1:-1;}return 0;}

async function orionActiveSession(){
  try{
    const x=await chrome.storage.local.get(ORION_ACTIVE_SESSION),v=x&&x[ORION_ACTIVE_SESSION];
    return v&&typeof v==='object'&&!Array.isArray(v)?v:null;
  }catch(_){return null;}
}
async function setOrionActiveSession(v){
  try{
    if(v)await chrome.storage.local.set({[ORION_ACTIVE_SESSION]:v});
    else await chrome.storage.local.remove(ORION_ACTIVE_SESSION);
  }catch(_){}
}
function cookieRemoveDetails(c){
  const host=String(c&&c.domain||'').replace(/^\./,'');
  const path=String(c&&c.path||'/');
  const q={url:(c&&c.secure?'https://':'http://')+host+(path.startsWith('/')?path:'/'+path),name:String(c&&c.name||'')};
  if(c&&c.storeId)q.storeId=c.storeId;
  if(c&&c.partitionKey)q.partitionKey=c.partitionKey;
  return q;
}
async function orionWipeHostCookies(host){
  host=ElloCookies.host(host);
  if(host==='ellostoreapk.com'||host.endsWith('.ellostoreapk.com'))return 0;
  let rows=await orionBound(chrome.cookies.getAll({domain:host}),1400,[]);
  if(!Array.isArray(rows))rows=[];
  let removed=0;
  for(const c of rows){
    try{
      const d=String(c&&c.domain||'').replace(/^\./,'').toLowerCase();
      if(!ElloCookies.inScope(d,host))continue;
      const r=await orionBound(chrome.cookies.remove(cookieRemoveDetails(c)),700,null);
      if(r)removed++;
    }catch(_){}
  }
  return removed;
}

let orionCookieClampBusy=false;
async function clampOrionCookieLease(c,host){
  if(orionCookieClampBusy||!c||!host)return;
  const domain=String(c.domain||'').replace(/^\./,'').toLowerCase();
  if(!ElloCookies.inScope(domain,host))return;
  const now=Math.floor(Date.now()/1000),expiry=Number(c.expirationDate||0);
  if(expiry>now&&expiry<=now+ORION_COOKIE_LEASE_SECONDS+8)return;
  const d={url:(c.secure?'https://':'http://')+domain+(String(c.path||'/').startsWith('/')?String(c.path||'/'):'/'+String(c.path||'/')),name:c.name,value:c.value,path:c.path||'/',secure:c.secure===true,httpOnly:c.httpOnly===true,sameSite:c.sameSite||'unspecified',expirationDate:now+ORION_COOKIE_LEASE_SECONDS};
  if(c.domain&&String(c.domain).startsWith('.'))d.domain=c.domain;
  if(c.storeId)d.storeId=c.storeId;
  if(c.partitionKey)d.partitionKey=c.partitionKey;
  try{orionCookieClampBusy=true;await chrome.cookies.set(d);}catch(_){}finally{orionCookieClampBusy=false;}
}

async function orionCloseHostTabs(host,exceptTabId=0){
  host=ElloCookies.host(host);
  let tabs=await orionBound(chrome.tabs.query({}),1200,[]);
  if(!Array.isArray(tabs))tabs=[];
  let n=0;
  for(const t of tabs){
    if(!t||!Number.isInteger(t.id)||t.id===exceptTabId)continue;
    let match=false;
    try{const u=new URL(String(t.url||''));match=u.protocol==='https:'&&ElloCookies.inScope(u.hostname,host);}catch(_){}
    if(!match)continue;
    const removed=await orionBound(chrome.tabs.remove(t.id).then(()=>true),650,false);
    if(removed){n++;continue;}
    const blanked=await orionBound(chrome.tabs.update(t.id,{url:'about:blank'}).then(()=>true),650,false);
    if(blanked)n++;
  }
  return n;
}
async function orionHardCleanupLocal(exceptHost=''){
  const reg=await leaseRegistry(),hosts=new Set(),tabIds=new Set();
  const active=await orionActiveSession();
  if(active&&active.host)hosts.add(String(active.host));
  for(const [k,e] of Object.entries(reg)){
    if(e&&e.orionIos===true){
      if(e.host)hosts.add(String(e.host));
      const tid=Number(k);if(Number.isInteger(tid))tabIds.add(tid);
      delete reg[k];
    }
  }
  if(exceptHost)hosts.add(String(exceptHost));

  // Release logical ownership first. A later Orion event cannot keep the old session alive.
  await saveLeaseRegistry(reg);
  await setOrionActiveSession(null);

  // SECURITY-CRITICAL: remove shared WebKit cookies BEFORE waiting on tab APIs.
  // tabs.remove / executeScript can become stuck in Orion iOS while switching tabs.
  for(const h of hosts){
    try{await orionWipeHostCookies(h);}catch(_){}
  }

  // UI cleanup is best effort and bounded. Never block a new menu indefinitely.
  const jobs=[];
  for(const tid of tabIds){
    jobs.push((async()=>{
      try{await orionBound(removeTabGuard(tid),500,null);}catch(_){}
      const removed=await orionBound(chrome.tabs.remove(tid).then(()=>true),650,false);
      if(!removed)await orionBound(chrome.tabs.update(tid,{url:'about:blank'}),650,null);
    })());
  }
  for(const h of hosts)jobs.push(orionCloseHostTabs(h,0));
  if(jobs.length)await orionBound(Promise.allSettled(jobs),2200,null);
  return true;
}

function desktopUaRuleId(host){
  let h=2166136261;
  for(const ch of String(host||'').toLowerCase()){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}
  return DESKTOP_UA_RULE_BASE+(Math.abs(h>>>0)%900000);
}
async function orionFailClosedActiveSession(reason=''){
  if(!await orionIOSHost())return false;
  const active=await orionActiveSession();
  if(!active)return false;
  try{await orionWipeHostCookies(active.host);}catch(_){}
  try{await orionCloseHostTabs(active.host,0);}catch(_){}
  try{await setOrionActiveSession(null);}catch(_){}
  try{
    const reg=await leaseRegistry();
    for(const [k,e] of Object.entries(reg))if(e&&e.orionIos===true)delete reg[k];
    await saveLeaseRegistry(reg);
  }catch(_){}
  return true;
}
async function orionPendingSession(){
  try{
    const x=await chrome.storage.local.get(ORION_PENDING_SESSION),v=x&&x[ORION_PENDING_SESSION];
    return v&&typeof v==='object'&&!Array.isArray(v)?v:null;
  }catch(_){return null;}
}
async function orionAdoptPendingTab(tabId,url){
  if(!Number.isInteger(Number(tabId))||!await orionIOSHost())return false;
  const pending=await orionPendingSession();
  if(!pending||!pending.host)return false;
  if(Date.now()-Number(pending.createdAt||0)>30000){
    try{await chrome.storage.local.remove(ORION_PENDING_SESSION);}catch(_){}
    try{await orionWipeHostCookies(pending.host);}catch(_){}
    return false;
  }

  let u=null;
  try{u=new URL(String(url||''));}catch(_){return false;}
  if(u.protocol!=='https:'||!ElloCookies.inScope(u.hostname,String(pending.host)))return false;

  tabId=Number(tabId);
  const now=Date.now();
  const active={
    tabId,
    uid:String(pending.uid||''),
    deviceId:String(pending.deviceId||''),
    host:String(pending.host||''),
    menuId:String(pending.menuId||''),
    itemId:String(pending.itemId||''),
    nonce:String(pending.nonce||''),
    createdAt:Number(pending.createdAt||now),
    lastOkAt:now
  };

  try{
    const reg=await leaseRegistry();
    reg[String(tabId)]={
      tabId,
      uid:active.uid,
      deviceId:active.deviceId,
      ownerKey:String(pending.ownerKey||active.uid+'|'+active.deviceId),
      refs:Array.isArray(pending.refs)?pending.refs:[],
      host:active.host,
      menuId:active.menuId,
      itemId:active.itemId,
      orionIos:true,
      createdAt:now,
      lastRefreshAt:now,
      lastOwnerOkAt:now,
      leaseUntil:now+ORION_COOKIE_LEASE_SECONDS*1000
    };
    await saveLeaseRegistry(reg);
    await setOrionActiveSession(active);

    const token=crypto.randomUUID?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');
    await saveTabGuard(tabId,{
      token,createdAt:now,
      uid:active.uid,deviceId:active.deviceId,
      ownerKey:String(pending.ownerKey||active.uid+'|'+active.deviceId),
      host:active.host,menuId:active.menuId,itemId:active.itemId,
      url:String(pending.url||url),
      cookieRefs:Array.isArray(pending.refs)?pending.refs:[],
      desktopMode:pending.desktopMode===true,
      orionIos:true
    });
    await chrome.storage.local.remove(ORION_PENDING_SESSION);
    injectOrionFileGuard(tabId).catch(()=>{});
    if(pending.desktopMode===true)applyDesktopLayout(tabId).catch(()=>{});
    return true;
  }catch(_){
    return false;
  }
}

async function orionEnforceSingleTab(tabId,url){
  if(!Number.isInteger(Number(tabId))||!await orionIOSHost())return true;
  const active=await orionActiveSession();
  if(!active||!active.host)return true;
  let u=null;
  try{u=new URL(String(url||''));}catch(_){return true;}
  if(!['http:','https:'].includes(u.protocol))return true;
  if(!ElloCookies.inScope(u.hostname,String(active.host)))return true;
  if(Number(active.tabId)===Number(tabId))return true;
  // Cookies are shared between tabs in WebKit. An extra tab to the protected host would
  // otherwise inherit the active login, so fail it closed immediately.
  try{await chrome.tabs.remove(Number(tabId));return false;}catch(_){}
  try{await chrome.tabs.update(Number(tabId),{url:'about:blank'});return false;}catch(_){}
  return false;
}
async function orionActiveTabRemoved(tabId){
  if(!await orionIOSHost())return;
  const active=await orionActiveSession();
  if(!active||Number(active.tabId)!==Number(tabId))return;
  try{await orionWipeHostCookies(active.host);}catch(_){}
  try{await setOrionActiveSession(null);}catch(_){}
}
async function orionResumeSweep(){
  if(!await orionIOSHost())return;

  const pending=await orionPendingSession();
  if(pending&&pending.host){
    let tabs=[];try{tabs=await chrome.tabs.query({})||[];}catch(_){}
    for(const t of tabs){
      if(!t||!Number.isInteger(t.id))continue;
      const u=String(t.url||t.pendingUrl||'');
      if(await orionAdoptPendingTab(t.id,u))break;
    }
  }

  const active=await orionActiveSession();
  if(!active||!active.host)return;
  let valid=true;
  try{
    if(!await syncWebsiteSession())throw Object.assign(new Error('Logout website'),{code:'SESSION_REVOKED'});
    await assertWebsiteSession();await assertDeviceActiveGuardCached(15000);
    const owner=await currentLeaseOwner();
    valid=!!owner&&String(owner.uid)===String(active.uid)&&String(owner.deviceId)===String(active.deviceId);
  }catch(e){valid=e&&['SESSION_REVOKED','DEVICE_REVOKED','EXTENSION_CONFLICT'].includes(e.code)?false:null;}
  if(valid===false||(valid===null&&Date.now()-Number(active.lastOkAt||active.createdAt||0)>15000)){await orionFailClosedActiveSession('session');return;}
  let tabs=[];try{tabs=await chrome.tabs.query({})||[];}catch(_){}
  let activeExists=false;
  for(const t of tabs){
    if(!t||!Number.isInteger(t.id))continue;
    if(Number(t.id)===Number(active.tabId))activeExists=true;
    const url=String(t.url||'');
    if(url)await orionEnforceSingleTab(t.id,url);
  }
  // Orion can report an empty tab list briefly after resuming. Do not confuse
  // a temporary enumeration failure with a confirmed closed tab.
  if(!activeExists){
    if(Date.now()-Number(active.lastOkAt||active.createdAt||0)<15000)return;
    await logGuardClose('ORION_TAB_MISSING',Number(active.tabId)||0);
    await orionFailClosedActiveSession('tab-lost');
  }
}

async function setDesktopNetworkProfile(host,desktop){
  host=ElloCookies.host(host);
  if(!hasDynamicNetRequest())return false;
  const rid=desktopUaRuleId(host);
  const removeRuleIds=[rid];
  if(!desktop){
    try{await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds});return true;}catch(_){return false;}
  }
  const resources=['main_frame','sub_frame','stylesheet','script','image','font','object','xmlhttprequest','ping','csp_report','media','websocket','other'];
  const rule={
    id:rid,priority:2000,
    action:{type:'modifyHeaders',requestHeaders:[
      {header:'user-agent',operation:'set',value:DESKTOP_UA}
    ]},
    condition:{urlFilter:'||'+host+'^',resourceTypes:resources}
  };
  try{
    await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds,addRules:[rule]});
    return true;
  }catch(_){return false;}
}
async function releaseInfo(force=false){if(!force&&releaseCache&&Date.now()-releaseCacheAt<30000)return releaseCache;releaseCache=await client.db('website/extensionRelease','GET',null,{public:true})||{};releaseCacheAt=Date.now();return releaseCache;}
function updateRequired(r){const requiredCode=Number(r&&r.versionCode)||versionCode(r&&r.version);if(requiredCode>0)return LOCAL_VERSION_CODE<requiredCode;const latest=String(r&&r.version||'').trim();return !!latest&&compareVersion(LOCAL_VERSION,latest)<0;}
async function assertCurrentVersion(){const r=await releaseInfo();if(updateRequired(r)){const e=new Error('Extension V'+LOCAL_VERSION+' sudah lama. Wajib update ke V'+r.version+' melalui website Ello Store.');e.code='UPDATE_REQUIRED';throw e;}return r;}

const GLOBAL_CONFIG_TTL_MS=10*60*1000;
const GLOBAL_DISPLAY_CACHE_KEY='elloGlobalDisplayCacheV1';
const GLOBAL_CATALOG_CACHE_KEY='elloGlobalCatalogCacheV1';
let globalDisplayCache=null,globalDisplayCacheAt=0,globalDisplayHydrated=false;
let globalCatalogCache=null,globalCatalogCacheAt=0,globalCatalogHydrated=false;

async function hydrateGlobalDisplayCache(){
  if(globalDisplayHydrated)return;
  globalDisplayHydrated=true;
  try{
    const x=await chrome.storage.local.get(GLOBAL_DISPLAY_CACHE_KEY),row=x&&x[GLOBAL_DISPLAY_CACHE_KEY];
    if(row&&typeof row==='object'){
      globalDisplayCache=row.data&&typeof row.data==='object'?row.data:null;
      globalDisplayCacheAt=Number(row.at)||0;
    }
  }catch(_){}
}
async function hydrateGlobalCatalogCache(){
  if(globalCatalogHydrated)return;
  globalCatalogHydrated=true;
  try{
    const x=await chrome.storage.local.get(GLOBAL_CATALOG_CACHE_KEY),row=x&&x[GLOBAL_CATALOG_CACHE_KEY];
    if(row&&typeof row==='object'){
      globalCatalogCache=row.data&&typeof row.data==='object'?row.data:null;
      globalCatalogCacheAt=Number(row.at)||0;
    }
  }catch(_){}
}
async function globalDisplayConfig(force=false){
  await hydrateGlobalDisplayCache();
  const now=Date.now();
  if(!force&&globalDisplayCache&&now-globalDisplayCacheAt<GLOBAL_CONFIG_TTL_MS)return globalDisplayCache;
  const [settings,catalogCategories,browserCfg]=await Promise.all([
    client.db('website/settings','GET',null,{public:true}),
    client.db('website/catalogCategories','GET',null,{public:true}),
    client.db('website/browserExtensionConfig','GET',null,{public:true})
  ]);
  globalDisplayCache={
    settings:settings||{},
    catalogCategories:catalogCategories||{},
    browserExtensionConfig:browserCfg||{}
  };
  globalDisplayCacheAt=now;
  try{await chrome.storage.local.set({[GLOBAL_DISPLAY_CACHE_KEY]:{at:now,data:globalDisplayCache}});}catch(_){}
  return globalDisplayCache;
}
async function globalCatalogStructure(force=false){
  await hydrateGlobalCatalogCache();
  const now=Date.now();
  if(!force&&globalCatalogCache&&now-globalCatalogCacheAt<GLOBAL_CONFIG_TTL_MS)return globalCatalogCache;
  const [menus,domains,manualMenus]=await Promise.all([
    client.db('extension/menus'),
    client.db('extension/domains'),
    client.db('manualCatalogs')
  ]);
  globalCatalogCache={menus:menus||{},domains:domains||{},manualMenus:manualMenus||{}};
  globalCatalogCacheAt=now;
  try{await chrome.storage.local.set({[GLOBAL_CATALOG_CACHE_KEY]:{at:now,data:globalCatalogCache}});}catch(_){}
  return globalCatalogCache;
}
async function clearGlobalConfigCache(){
  globalDisplayCache=null;globalDisplayCacheAt=0;globalDisplayHydrated=true;
  globalCatalogCache=null;globalCatalogCacheAt=0;globalCatalogHydrated=true;
  try{await chrome.storage.local.remove([GLOBAL_DISPLAY_CACHE_KEY,GLOBAL_CATALOG_CACHE_KEY]);}catch(_){}
}

const URL_GUARD_RULE_BASE=8700000,URL_GUARD_SYNC_MINUTES=10;
const URL_GUARD_REVISION_CHECK_MS=URL_GUARD_SYNC_MINUTES*60*1000;
let urlGuardCache=[],urlGuardSyncedAt=0,urlGuardRevision=0,urlGuardRevisionCheckedAt=0,urlGuardSnapshotReady=false,urlGuardHydrated=false;
function hasDynamicNetRequest(){
  return !!(globalThis.chrome&&chrome.declarativeNetRequest&&
    typeof chrome.declarativeNetRequest.getDynamicRules==='function'&&
    typeof chrome.declarativeNetRequest.updateDynamicRules==='function');
}
function extensionSessionStorage(){
  if(chrome.storage&&chrome.storage.session&&
     typeof chrome.storage.session.get==='function'&&
     typeof chrome.storage.session.set==='function'&&
     typeof chrome.storage.session.remove==='function')return chrome.storage.session;
  return chrome.storage.local;
}
function mobileExtensionHost(){
  const ua=String(globalThis.navigator&&navigator.userAgent||'');
  return /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
}
async function browserExtensionConfig(force=false){
  try{
    const cfg=await globalDisplayConfig(force);
    return cfg&&cfg.browserExtensionConfig||{};
  }catch(_){return{};}
}
function desktopLayoutPatch(){
  const apply=()=>{
    try{
      let meta=document.querySelector('meta[name="viewport"]');
      if(!meta){meta=document.createElement('meta');meta.name='viewport';(document.head||document.documentElement).appendChild(meta);}
      meta.setAttribute('content','width=1280, initial-scale=0.30, minimum-scale=0.10, maximum-scale=5, user-scalable=yes');
      document.documentElement.style.minWidth='1180px';
      if(document.body)document.body.style.minWidth='1180px';
    }catch(_){}
  };
  apply();
  if(!globalThis.__elloDesktopLayoutObserver){
    try{globalThis.__elloDesktopLayoutObserver=new MutationObserver(apply);globalThis.__elloDesktopLayoutObserver.observe(document.documentElement,{childList:true,subtree:true});}catch(_){}
  }
}
async function applyDesktopLayout(tabId){
  tabId=Number(tabId);if(!Number.isInteger(tabId))return false;
  if(chrome.scripting&&typeof chrome.scripting.executeScript==='function'){
    try{await chrome.scripting.executeScript({target:{tabId},func:desktopLayoutPatch});return true;}catch(_){}
  }
  if(chrome.tabs&&typeof chrome.tabs.executeScript==='function'){
    try{await chrome.tabs.executeScript(tabId,{code:'('+desktopLayoutPatch.toString()+')();',runAt:'document_start'});return true;}catch(_){}
  }
  return false;
}
function escapeRe(s){return String(s).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function normalizeGuardUrl(raw){try{const u=new URL(String(raw||''));if(u.protocol!=='https:'&&u.protocol!=='http:')return'';return u.href;}catch(_){return'';}}
function guardMatches(g,raw){const u=normalizeGuardUrl(raw),base=normalizeGuardUrl(g&&g.url);if(!u||!base)return false;if(g.match==='exact')return u===base;if(g.match==='suffix'){try{const cur=new URL(u),rule=new URL(base);if(cur.origin!==rule.origin)return false;const suffix=rule.hash||(rule.pathname&&rule.pathname!=='/'?rule.pathname+rule.search:rule.search);return !!suffix&&u.endsWith(suffix);}catch(_){return false;}}return u.startsWith(base);}
function guardRuleId(key,index){let h=2166136261;for(const c of String(key)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return URL_GUARD_RULE_BASE+((h>>>0)%900000)+index%97;}
function dnrRegex(g){const base=normalizeGuardUrl(g.url);if(!base)return'';const u=new URL(base);if(u.hash||g.match==='suffix')return'';const escaped=escapeRe(base);return g.match==='exact'?'^'+escaped+'$':'^'+escaped+'.*';}
async function hydrateUrlGuardState(){
  if(urlGuardHydrated)return;
  urlGuardHydrated=true;
  try{
    const x=await chrome.storage.local.get([
      'elloUrlGuards','elloUrlGuardsAt','elloUrlGuardRevision',
      'elloUrlGuardRevisionCheckedAt','elloUrlGuardSnapshotReady'
    ]);
    urlGuardCache=Array.isArray(x.elloUrlGuards)?x.elloUrlGuards:[];
    urlGuardSyncedAt=Number(x.elloUrlGuardsAt)||0;
    urlGuardRevision=Number(x.elloUrlGuardRevision)||0;
    urlGuardRevisionCheckedAt=Number(x.elloUrlGuardRevisionCheckedAt)||0;
    urlGuardSnapshotReady=x.elloUrlGuardSnapshotReady===true;
  }catch(_){}
}
async function saveUrlGuardLocalState(){
  try{
    await chrome.storage.local.set({
      elloUrlGuards:urlGuardCache,
      elloUrlGuardsAt:urlGuardSyncedAt,
      elloUrlGuardRevision:urlGuardRevision,
      elloUrlGuardRevisionCheckedAt:urlGuardRevisionCheckedAt,
      elloUrlGuardSnapshotReady:urlGuardSnapshotReady
    });
  }catch(_){}
}
async function loadUrlGuards(force=false){
  await hydrateUrlGuardState();
  const now=Date.now();

  // Di antara interval revision-check, pakai rules lokal sepenuhnya.
  if(!force&&urlGuardSnapshotReady&&now-urlGuardRevisionCheckedAt<URL_GUARD_REVISION_CHECK_MS){
    return{rows:urlGuardCache,changed:false};
  }

  let remoteRevision=0,revisionReadable=false;
  try{
    const raw=await client.db('website/urlGuardRevision','GET',null,{public:true});
    remoteRevision=Number(raw)||0;
    revisionReadable=remoteRevision>0;
    urlGuardRevisionCheckedAt=now;
  }catch(_){
    if(urlGuardSnapshotReady)return{rows:urlGuardCache,changed:false};
  }

  // Revision sama -> tidak download daftar URL Guard penuh.
  if(!force&&revisionReadable&&urlGuardSnapshotReady&&remoteRevision===urlGuardRevision){
    await saveUrlGuardLocalState();
    return{rows:urlGuardCache,changed:false};
  }

  // Kompatibilitas database lama yang belum punya revision:
  // rules penuh maksimum sekali per 10 menit, bukan setiap popup/message.
  if(!force&&!revisionReadable&&urlGuardSnapshotReady&&now-urlGuardSyncedAt<URL_GUARD_REVISION_CHECK_MS){
    await saveUrlGuardLocalState();
    return{rows:urlGuardCache,changed:false};
  }

  let data={};
  try{
    data=await client.db('website/urlGuards','GET',null,{public:true})||{};
  }catch(_){
    return{rows:urlGuardCache,changed:false};
  }

  urlGuardCache=Object.entries(data)
    .filter(([,x])=>x&&x.enabled!==false&&normalizeGuardUrl(x.url))
    .sort((a,b)=>(Number(a[1].order)||0)-(Number(b[1].order)||0))
    .map(([id,x])=>({
      id,
      name:String(x.name||'URL diblokir').slice(0,120),
      url:normalizeGuardUrl(x.url),
      match:x.match==='exact'?'exact':(x.match==='suffix'?'suffix':'prefix'),
      action:x.action==='close'?'close':'back'
    }));
  urlGuardSyncedAt=now;
  urlGuardRevision=revisionReadable?remoteRevision:urlGuardRevision;
  urlGuardRevisionCheckedAt=now;
  urlGuardSnapshotReady=true;
  await saveUrlGuardLocalState();
  return{rows:urlGuardCache,changed:true};
}
async function syncUrlGuardRules(force=false){
  const result=await loadUrlGuards(force),rows=result.rows;
  // Rules lokal tetap aktif terus. DNR hanya dibangun ulang bila revision berubah
  // atau pengguna menekan Refresh (force=true).
  if(!result.changed&&!force)return rows;
  if(!hasDynamicNetRequest())return rows;
  try{
    const old=await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds=(old||[]).filter(r=>r.id>=URL_GUARD_RULE_BASE&&r.id<URL_GUARD_RULE_BASE+1000000).map(r=>r.id);
    const used=new Set(),addRules=[];
    for(let i=0;i<rows.length;i++){
      const g=rows[i],regex=dnrRegex(g);if(!regex)continue;
      let id=guardRuleId(g.id,i);while(used.has(id))id++;used.add(id);
      addRules.push({id,priority:1000+i,action:{type:'block'},condition:{regexFilter:regex,resourceTypes:['main_frame']}});
    }
    await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds,addRules});
  }catch(e){
    // Do not break the popup/catalog when a browser implements only part of DNR.
    console.warn('Network rule API tidak tersedia penuh; memakai navigation guard fallback.',e);
  }
  return rows;
}
async function cachedUrlGuards(){await hydrateUrlGuardState();return urlGuardCache;}
async function handleGuardedTab(tabId,url){if(!url||url.startsWith('chrome-extension://')||url.startsWith('edge://')||url.startsWith('chrome://'))return;const rows=await cachedUrlGuards(),g=rows.find(x=>guardMatches(x,url));if(!g)return;if(g.action==='close'){try{await chrome.tabs.remove(tabId);}catch(_){}return;}try{await chrome.tabs.goBack(tabId);}catch(_){try{await chrome.tabs.update(tabId,{url:'about:blank'});}catch(_){}}}
chrome.runtime.onInstalled.addListener(()=>{try{if(chrome.alarms&&chrome.alarms.create){chrome.alarms.create('elloUrlGuardSync',{periodInMinutes:URL_GUARD_SYNC_MINUTES});chrome.alarms.create(COOKIE_LEASE_ALARM,{periodInMinutes:0.5});chrome.alarms.create(EXTENSION_POLICY_ALARM,{periodInMinutes:0.5});}}catch(_){}syncUrlGuardRules(true).catch(()=>{});bootstrapCookieSafety().catch(()=>{});enforceExclusiveExtensionNow(true).catch(()=>{});});
chrome.runtime.onStartup.addListener(()=>{try{if(chrome.alarms&&chrome.alarms.create){chrome.alarms.create('elloUrlGuardSync',{periodInMinutes:URL_GUARD_SYNC_MINUTES});chrome.alarms.create(COOKIE_LEASE_ALARM,{periodInMinutes:0.5});chrome.alarms.create(EXTENSION_POLICY_ALARM,{periodInMinutes:0.5});}}catch(_){}syncUrlGuardRules(true).catch(()=>{});bootstrapCookieSafety().catch(()=>{});enforceExclusiveExtensionNow(true).catch(()=>{});});
if(chrome.alarms&&chrome.alarms.onAlarm)chrome.alarms.onAlarm.addListener(a=>{if(!a)return;if(a.name==='elloUrlGuardSync')syncUrlGuardRules(true).catch(()=>{});if(a.name===COOKIE_LEASE_ALARM){maintainCookieLeases().catch(()=>{});orionResumeSweep().catch(()=>{});}if(a.name===EXTENSION_POLICY_ALARM)enforceExclusiveExtensionNow(true).catch(()=>{});});


const EXTENSION_POLICY_ALARM='elloExclusiveExtensionPolicy',EXTENSION_POLICY_CACHE_MS=1500;
let extensionPolicyCache={at:0,rows:[]},extensionPolicyPending=null;
function allowedCompanionExtension(x){
  const name=String(x&&x.name||'').trim();
  return /^Q30 from Quetta(?: Translator)?$/i.test(name);
}
function isOtherUserExtension(x){
  return !!x&&x.id!==chrome.runtime.id&&x.enabled===true&&x.type==='extension'&&x.mayDisable!==false&&!allowedCompanionExtension(x);
}
function invalidateExtensionPolicyCache(){extensionPolicyCache={at:0,rows:[]};extensionPolicyPending=null;}
async function otherEnabledExtensions(force=false){
  if(await orionIOSHost())return[];
  if(!chrome.management||!chrome.management.getAll)return[];
  const now=Date.now();
  if(!force&&now-extensionPolicyCache.at<EXTENSION_POLICY_CACHE_MS)return extensionPolicyCache.rows;
  if(!force&&extensionPolicyPending)return extensionPolicyPending;
  extensionPolicyPending=(async()=>{
    let rows=[];try{rows=await chrome.management.getAll();}catch(_){rows=[];}
    const out=rows.filter(isOtherUserExtension).map(x=>({id:x.id,name:String(x.name||'Extension lain').slice(0,80)}));
    extensionPolicyCache={at:Date.now(),rows:out};extensionPolicyPending=null;return out;
  })();
  return extensionPolicyPending;
}
async function assertExclusiveExtension(force=false){
  const rows=await otherEnabledExtensions(force);if(!rows.length)return true;
  const names=rows.slice(0,4).map(x=>x.name).join(', '),more=rows.length>4?' +'+(rows.length-4)+' lainnya':'';
  const e=new Error('Proteksi Ello Store aktif. Saat membuka menu cookie, hanya Extension Ello Store yang boleh aktif. Nonaktifkan extension lain terlebih dahulu: '+names+more+'.');
  e.code='EXTENSION_CONFLICT';throw e;
}
async function enforceExclusiveExtensionNow(force=true){
  try{await assertExclusiveExtension(force);return true;}
  catch(_){await emergencyCleanupAll();return false;}
}
const COOKIE_LEASE_SECONDS=180,COOKIE_LEASE_REFRESH_MS=45000,COOKIE_LEASE_ALARM='elloCookieLeaseMaintenance',COOKIE_LEASE_REGISTRY='elloCookieLeaseRegistry',RUNTIME_MARKER='elloRuntimeMarker';
function cookieRefKey(r){return [String(r&&r.storeId||''),String(r&&r.domain||'').toLowerCase(),String(r&&r.path||'/'),String(r&&r.name||''),JSON.stringify(r&&r.partitionKey||null)].join('|');}
function cookieRefFromCookie(c){return{name:String(c.name||''),domain:String(c.domain||''),path:String(c.path||'/'),storeId:String(c.storeId||''),secure:c.secure===true,hostOnly:c.hostOnly===true,partitionKey:c.partitionKey||null};}
function cookieRefUrl(r){const host=String(r&&r.domain||'').replace(/^\./,'');const path=String(r&&r.path||'/');return (r&&r.secure?'https://':'http://')+host+(path.startsWith('/')?path:'/'+path);}
async function leaseRegistry(){const x=await chrome.storage.local.get(COOKIE_LEASE_REGISTRY),r=x&&x[COOKIE_LEASE_REGISTRY];return r&&typeof r==='object'&&!Array.isArray(r)?r:{};}
async function saveLeaseRegistry(r){await chrome.storage.local.set({[COOKIE_LEASE_REGISTRY]:r&&typeof r==='object'?r:{}});}
async function getCookieByRef(r){const q={url:cookieRefUrl(r),name:r.name};if(r.storeId)q.storeId=r.storeId;if(r.partitionKey)q.partitionKey=r.partitionKey;try{return await chrome.cookies.get(q);}catch(_){return null;}}
async function refreshCookieRef(r,ttlSeconds=COOKIE_LEASE_SECONDS){const c=await getCookieByRef(r);if(!c)return false;const d={url:cookieRefUrl(r),name:c.name,value:c.value,path:c.path||'/',secure:c.secure===true,httpOnly:c.httpOnly===true,sameSite:c.sameSite||'unspecified',expirationDate:Math.floor(Date.now()/1000)+ttlSeconds};if(!c.hostOnly)d.domain=c.domain;if(c.storeId)d.storeId=c.storeId;if(c.partitionKey)d.partitionKey=c.partitionKey;try{return !!(await chrome.cookies.set(d));}catch(_){return false;}}
async function removeCookieRef(r){const q={url:cookieRefUrl(r),name:r.name};if(r.storeId)q.storeId=r.storeId;if(r.partitionKey)q.partitionKey=r.partitionKey;try{await chrome.cookies.remove(q);}catch(_){}}
function leaseOwnerKey(uid,deviceId){return String(uid||'')+'|'+String(deviceId||'');}
function sameLeaseOwner(entry,uid,deviceId){return !!entry&&String(entry.uid||'')===String(uid||'')&&String(entry.deviceId||'')===String(deviceId||'');}
async function currentLeaseOwner(){if(!client.session||!client.session.uid)return null;const did=await getDeviceId();return{uid:String(client.session.uid),deviceId:String(did),key:leaseOwnerKey(client.session.uid,did)};}
async function registerCookieLease(tabId,refs,meta){if(!Number.isInteger(tabId)||!Array.isArray(refs)||!refs.length)return;const owner=await currentLeaseOwner();if(!owner)throw new Error('Sesi pengguna tidak tersedia.');const reg=await leaseRegistry(),dedup={},now=Date.now(),isOrion=meta&&meta.orionIos===true,ttl=isOrion?ORION_COOKIE_LEASE_SECONDS:COOKIE_LEASE_SECONDS;for(const r of refs)if(r&&r.name&&r.domain)dedup[cookieRefKey(r)]=r;reg[String(tabId)]={tabId,uid:owner.uid,deviceId:owner.deviceId,ownerKey:owner.key,refs:Object.values(dedup),host:String(meta&&meta.host||''),menuId:String(meta&&meta.menuId||''),itemId:String(meta&&meta.itemId||''),orionIos:isOrion,createdAt:now,lastRefreshAt:now,lastOwnerOkAt:now,leaseUntil:now+ttl*1000};await saveLeaseRegistry(reg);}
async function refreshCookieLeaseForTab(tabId,force=false){const reg=await leaseRegistry(),k=String(tabId),entry=reg[k];if(!entry||!Array.isArray(entry.refs))return false;const now=Date.now(),isOrion=entry.orionIos===true,refreshMs=isOrion?ORION_COOKIE_REFRESH_MS:COOKIE_LEASE_REFRESH_MS,ttl=isOrion?ORION_COOKIE_LEASE_SECONDS:COOKIE_LEASE_SECONDS;if(!force&&now-Number(entry.lastRefreshAt||0)<refreshMs)return true;let alive=false;for(const r of entry.refs)if(await refreshCookieRef(r,ttl))alive=true;entry.lastRefreshAt=now;entry.leaseUntil=now+ttl*1000;reg[k]=entry;await saveLeaseRegistry(reg);return alive;}
async function cleanupCookieLeaseForTab(tabId,closeTab=false){
  const reg=await leaseRegistry(),k=String(tabId),entry=reg[k];
  if(entry)delete reg[k];
  const still=new Set();
  for(const x of Object.values(reg))for(const r of Array.isArray(x&&x.refs)?x.refs:[])still.add(cookieRefKey(r));
  if(entry&&Array.isArray(entry.refs))for(const r of entry.refs)if(!still.has(cookieRefKey(r)))await removeCookieRef(r);
  await saveLeaseRegistry(reg);
  try{await removeTabGuard(tabId);}catch(_){}
  if(entry&&entry.orionIos===true&&entry.host){
    try{await orionWipeHostCookies(entry.host);}catch(_){}
    const active=await orionActiveSession();
    if(active&&Number(active.tabId)===Number(tabId))await setOrionActiveSession(null);
  }
  if(closeTab){
    let removed=false;
    try{await chrome.tabs.remove(Number(tabId));removed=true;}catch(_){}
    if(entry&&entry.orionIos===true&&!removed){
      try{await chrome.tabs.update(Number(tabId),{url:'about:blank'});}catch(_){}
    }
  }
}
async function cleanupOwnerLeases(uid,deviceId,closeTabs=true){const reg=await leaseRegistry(),targets=[];for(const [k,entry]of Object.entries(reg)){if(sameLeaseOwner(entry,uid,deviceId)){const tabId=Number(k);if(Number.isInteger(tabId))targets.push(tabId);}}for(const tabId of targets)await cleanupCookieLeaseForTab(tabId,closeTabs);return targets.length;}
async function cleanupOwnerCatalogLeases(uid,deviceId,menuId,closeTabs=true){const reg=await leaseRegistry(),targets=[],catalogId=String(menuId||'');for(const [k,entry]of Object.entries(reg)){if(sameLeaseOwner(entry,uid,deviceId)&&String(entry&&entry.menuId||'')===catalogId){const tabId=Number(k);if(Number.isInteger(tabId))targets.push(tabId);}}for(const tabId of targets)await cleanupCookieLeaseForTab(tabId,closeTabs);return targets.length;}
async function cleanupForeignLocalLeases(uid,deviceId){const reg=await leaseRegistry(),targets=[];for(const [k,entry]of Object.entries(reg)){if(!sameLeaseOwner(entry,uid,deviceId)){const tabId=Number(k);if(Number.isInteger(tabId))targets.push(tabId);}}for(const tabId of targets)await cleanupCookieLeaseForTab(tabId,true);return targets.length;}
async function logGuardClose(reason,tabId=0){
  try{
    const key='elloGuardCloseDiagnostics',old=await chrome.storage.local.get(key);
    const rows=Array.isArray(old&&old[key])?old[key]:[];
    rows.push({reason:String(reason||'UNKNOWN').slice(0,60),tabId:Number(tabId)||0,at:Date.now()});
    await chrome.storage.local.set({[key]:rows.slice(-25)});
  }catch(_){}
}
async function emergencyCleanupAll(){
  const reg=await leaseRegistry(),refs={},tabs=[],hosts=new Set();
  for(const [k,x]of Object.entries(reg)){
    const id=Number(k);if(Number.isInteger(id))tabs.push(id);
    if(x&&x.orionIos===true&&x.host)hosts.add(String(x.host));
    for(const r of Array.isArray(x&&x.refs)?x.refs:[])refs[cookieRefKey(r)]=r;
  }
  const active=await orionActiveSession();
  if(active&&active.host)hosts.add(String(active.host));
  await saveLeaseRegistry({});
  await setOrionActiveSession(null);
  await Promise.all(Object.values(refs).map(removeCookieRef));
  for(const h of hosts){try{await orionWipeHostCookies(h);}catch(_){}try{await orionCloseHostTabs(h,0);}catch(_){}}
  for(const id of tabs){try{await chrome.tabs.remove(id);}catch(_){try{await chrome.tabs.update(id,{url:'about:blank'});}catch(__){}}try{await removeTabGuard(id);}catch(_){}}
}
async function leaseOwnerStillActive(entry){
 if(!entry||!entry.uid||!entry.deviceId)return false;
 try{
   if(!await syncWebsiteSession()||!client.session||String(client.session.uid)!==String(entry.uid))return false;
   const did=await getDeviceId();
   if(String(did)!==String(entry.deviceId))return false;
   await assertDeviceActiveGuardCached(15000);
   return true;
 }catch(e){
   if(e&&['SESSION_REVOKED','DEVICE_REVOKED','EXTENSION_CONFLICT'].includes(e.code))return false;
   return null; // Unknown (e.g. Firebase latency), never turn into a confirmed violation.
 }
}
async function maintainCookieLeases(){
  const reg=await leaseRegistry(),ownerChecks=new Map();
  for(const k of Object.keys(reg)){
    const tabId=Number(k),entry=reg[k];
    if(!Number.isInteger(tabId)){delete reg[k];continue;}
    let exists=true;try{await chrome.tabs.get(tabId);}catch(_){exists=false;}
    if(!exists){
      if(entry&&entry.orionIos===true&&entry.host)try{await orionWipeHostCookies(entry.host);}catch(_){}
      await cleanupCookieLeaseForTab(tabId,false);continue;
    }
    const okKey=leaseOwnerKey(entry&&entry.uid,entry&&entry.deviceId);
    let ownerOk=ownerChecks.get(okKey);
    if(ownerOk===undefined){ownerOk=await leaseOwnerStillActive(entry);ownerChecks.set(okKey,ownerOk);}
    if(ownerOk===true){
      // Keep the timestamp for bounded retry on a future transient failure.
      entry.lastOwnerOkAt=Date.now();
      const latest=await leaseRegistry();
      if(latest[k]){latest[k].lastOwnerOkAt=entry.lastOwnerOkAt;await saveLeaseRegistry(latest);}
      await refreshCookieLeaseForTab(tabId,false);
      continue;
    }
    if(ownerOk===null&&Date.now()-Number(entry.lastOwnerOkAt||entry.createdAt||0)<15000){
      // Failure to reach Firebase is not the same as a revoked account.
      continue;
    }
    await logGuardClose(ownerOk===false?'OWNER_REVOKED':'OWNER_UNVERIFIED_TIMEOUT',tabId);
    await cleanupCookieLeaseForTab(tabId,true);
  }
}
async function bootstrapCookieSafety(){
  const ss=extensionSessionStorage();let marker={};
  try{marker=await ss.get(RUNTIME_MARKER);}catch(_){}
  const reg=await leaseRegistry();
  if(!marker||!marker[RUNTIME_MARKER]){
    if(Object.keys(reg).length){await logGuardClose('RUNTIME_MARKER_MISSING',0);await emergencyCleanupAll();}
    try{await ss.set({[RUNTIME_MARKER]:Date.now()});}catch(_){}
  }else{
    try{await ss.set({[RUNTIME_MARKER]:Date.now()});}catch(_){}
  }
  try{
    if(chrome.alarms&&chrome.alarms.create){
      chrome.alarms.create(COOKIE_LEASE_ALARM,{periodInMinutes:0.5});
      chrome.alarms.create(EXTENSION_POLICY_ALARM,{periodInMinutes:0.5});
    }
  }catch(_){}
  const active=await orionActiveSession();
  if(active){
    try{
      const ok=await leaseOwnerStillActive(active);
      if(ok===false||(ok===null&&Date.now()-Number(active.lastOkAt||active.createdAt||0)>15000))await orionHardCleanupLocal();
    }catch(_){}
  }
}
function leaseSetDetails(d,ttlSeconds=COOKIE_LEASE_SECONDS){const x=Object.assign({},d);x.expirationDate=Math.floor(Date.now()/1000)+ttlSeconds;return x;}
function guardStorageKey(tabId){return'elloTabGuard_'+String(tabId);}
async function saveTabGuard(tabId,data){await extensionSessionStorage().set({[guardStorageKey(tabId)]:data});}
async function getTabGuard(tabId){const k=guardStorageKey(tabId),x=await extensionSessionStorage().get(k);return x[k]||null;}
async function removeTabGuard(tabId){await extensionSessionStorage().remove(guardStorageKey(tabId));}
function isolatedGuardPulse(token){
  // Runs in Chrome's ISOLATED world. The page cannot read the heartbeat token
  // or spoof the heartbeat with window.postMessage.
  try{if(globalThis.__elloStorePulseTimer)clearInterval(globalThis.__elloStorePulseTimer);}catch(_){}
  let locked=false,lastOk=Date.now();
  const lock=()=>{if(locked)return;locked=true;try{window.stop();}catch(_){}
    try{document.title='Akses Ello Store berakhir';document.documentElement.replaceChildren();const head=document.createElement('head'),meta=document.createElement('meta'),title=document.createElement('title'),body=document.createElement('body'),main=document.createElement('main'),h=document.createElement('h1'),p=document.createElement('p');meta.charset='utf-8';title.textContent='Akses Ello Store berakhir';head.append(meta,title);body.style.cssText='margin:0;background:#0b0811;color:#f5efff;font:16px system-ui;display:grid;place-items:center;min-height:100vh';main.style.cssText='max-width:520px;padding:28px;text-align:center';h.style.fontSize='28px';h.textContent='Akses ditutup';p.textContent='Extension Ello Store sudah tidak aktif atau sesi akses telah berakhir. Aktifkan kembali Ello Store lalu buka menu dari extension.';main.append(h,p);body.append(main);document.documentElement.append(head,body);}catch(_){}
    try{window.close();}catch(_){}
    setTimeout(()=>{try{location.replace('about:blank');}catch(_){}},80);
  };
  let pulseInFlight=false;
  const pulse=async()=>{
    if(locked||pulseInFlight)return;
    pulseInFlight=true;
    let timer=null;
    try{
      const r=await Promise.race([
        chrome.runtime.sendMessage({type:'TAB_GUARD_PING',token}),
        new Promise(resolve=>{timer=setTimeout(()=>resolve(null),3200);})
      ]);
      if(r&&r.ok===true){lastOk=Date.now();return;}
    }catch(_){}finally{if(timer)clearTimeout(timer);pulseInFlight=false;}
    if(Date.now()-lastOk>12000)lock();
  };
  pulse();globalThis.__elloStorePulseTimer=setInterval(pulse,1200);
}
async function injectTabGuard(tabId,token){
  if(chrome.scripting&&typeof chrome.scripting.executeScript==='function'){
    try{
      await chrome.scripting.executeScript({target:{tabId},world:'ISOLATED',func:isolatedGuardPulse,args:[token]});
      return true;
    }catch(_){}
  }
  if(chrome.tabs&&typeof chrome.tabs.executeScript==='function'){
    try{
      const code='('+isolatedGuardPulse.toString()+')('+JSON.stringify(token)+');';
      await chrome.tabs.executeScript(Number(tabId),{code,runAt:'document_start'});
      return true;
    }catch(_){}
  }
  return false;
}
async function injectOrionFileGuard(tabId){
  if(chrome.scripting&&typeof chrome.scripting.executeScript==='function'){
    const ok=await orionBound(
      chrome.scripting.executeScript({target:{tabId:Number(tabId)},files:['orion-guard.js']}).then(()=>true),
      900,false
    );
    if(ok)return true;
  }
  if(chrome.tabs&&typeof chrome.tabs.executeScript==='function'){
    const ok=await orionBound(
      chrome.tabs.executeScript(Number(tabId),{file:'orion-guard.js',runAt:'document_start'}).then(()=>true),
      900,false
    );
    if(ok)return true;
  }
  return false;
}
async function armTabGuard(tabId,meta){
  if(!Number.isInteger(tabId))return false;
  const token=crypto.randomUUID?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');
  const data=Object.assign({token,createdAt:Date.now()},meta||{});
  await saveTabGuard(tabId,data);
  const tries=data.orionIos===true?2:7;
  for(let i=0;i<tries;i++){
    try{
      if(data.orionIos===true){
        if(await injectOrionFileGuard(tabId))return true;
      }else if(await injectTabGuard(tabId,token))return true;
    }catch(_){}
    await new Promise(r=>setTimeout(r,data.orionIos===true?180:450));
  }
  return false;
}
if(chrome.tabs&&chrome.tabs.onCreated)chrome.tabs.onCreated.addListener(tab=>{
  try{
    const u=String(tab&&((tab.pendingUrl||tab.url))||'');
    if(u&&Number.isInteger(tab.id)){
      orionAdoptPendingTab(tab.id,u).then(adopted=>{
        if(!adopted)orionEnforceSingleTab(tab.id,u).catch(()=>{});
      }).catch(()=>orionEnforceSingleTab(tab.id,u).catch(()=>{}));
    }
  }catch(_){}
});
if(chrome.tabs&&chrome.tabs.onUpdated)chrome.tabs.onUpdated.addListener((tabId,changeInfo,tab)=>{
  const nextUrl=String(changeInfo&&changeInfo.url||tab&&tab.url||'');
  if(nextUrl){
    handleGuardedTab(tabId,nextUrl).catch(()=>{});
    orionAdoptPendingTab(tabId,nextUrl).then(adopted=>{
      if(!adopted)orionEnforceSingleTab(tabId,nextUrl).catch(()=>{});
    }).catch(()=>orionEnforceSingleTab(tabId,nextUrl).catch(()=>{}));
  }
  getTabGuard(tabId).then(async g=>{
    if(!g)return;
    if(nextUrl){
      try{
        const u=new URL(nextUrl);
        if(u.protocol!=='https:'||!ElloCookies.inScope(u.hostname,g.host)){
          await cleanupCookieLeaseForTab(tabId,true);
          return;
        }
      }catch(_){
        await cleanupCookieLeaseForTab(tabId,true);
        return;
      }
    }
    if(g.desktopMode===true&&changeInfo&&(changeInfo.status==='loading'||changeInfo.status==='complete'))await applyDesktopLayout(tabId);
    if(changeInfo&&changeInfo.status==='complete'&&g.token){
      // Orion must never receive the Chromium isolated heartbeat guard here.
      // That guard intentionally fail-closes after ~4.5 s without TAB_GUARD_PING,
      // while Orion background messaging is known to be intermittent.
      if(g.orionIos===true)await injectOrionFileGuard(tabId);
      else await injectTabGuard(tabId,g.token);
    }
  }).catch(()=>{});
});
if(chrome.tabs&&chrome.tabs.onActivated)chrome.tabs.onActivated.addListener(info=>{chrome.tabs.get(info.tabId).then(tab=>{const u=tab&&tab.url||'';handleGuardedTab(info.tabId,u).catch(()=>{});orionEnforceSingleTab(info.tabId,u).catch(()=>{});}).catch(()=>{});});
if(chrome.webNavigation&&chrome.webNavigation.onBeforeNavigate)chrome.webNavigation.onBeforeNavigate.addListener(d=>{if(Number.isInteger(d.tabId)&&d.frameId===0){handleGuardedTab(d.tabId,d.url).catch(()=>{});orionEnforceSingleTab(d.tabId,d.url).catch(()=>{});}});
if(chrome.webNavigation&&chrome.webNavigation.onCommitted)chrome.webNavigation.onCommitted.addListener(d=>{if(Number.isInteger(d.tabId)&&d.frameId===0){handleGuardedTab(d.tabId,d.url).catch(()=>{});orionEnforceSingleTab(d.tabId,d.url).catch(()=>{});}});
if(chrome.webNavigation&&chrome.webNavigation.onReferenceFragmentUpdated)chrome.webNavigation.onReferenceFragmentUpdated.addListener(d=>{if(Number.isInteger(d.tabId)&&d.frameId===0){handleGuardedTab(d.tabId,d.url).catch(()=>{});orionEnforceSingleTab(d.tabId,d.url).catch(()=>{});}});
if(chrome.tabs&&chrome.tabs.onRemoved)chrome.tabs.onRemoved.addListener(tabId=>{orionActiveTabRemoved(tabId).catch(()=>{});cleanupCookieLeaseForTab(tabId,false).catch(()=>{});});
async function installExtensionPolicyListeners(){
  try{
    if(await orionIOSHost(true))return;
    if(!chrome.management)return;
    if(chrome.management.onInstalled)chrome.management.onInstalled.addListener(info=>{invalidateExtensionPolicyCache();if(info&&info.id!==chrome.runtime.id&&info.type==='extension'&&info.mayDisable!==false&&!allowedCompanionExtension(info))emergencyCleanupAll().catch(()=>{});});
    if(chrome.management.onEnabled)chrome.management.onEnabled.addListener(info=>{invalidateExtensionPolicyCache();if(isOtherUserExtension(info))emergencyCleanupAll().catch(()=>{});});
    if(chrome.management.onDisabled)chrome.management.onDisabled.addListener(info=>{invalidateExtensionPolicyCache();if(info&&info.id===chrome.runtime.id)emergencyCleanupAll().catch(()=>{});});
    if(chrome.management.onUninstalled)chrome.management.onUninstalled.addListener(extId=>{invalidateExtensionPolicyCache();if(extId===chrome.runtime.id)emergencyCleanupAll().catch(()=>{});});
  }catch(_){}
}
setTimeout(()=>{installExtensionPolicyListeners().catch(()=>{});},800);
// Logout website hanya membersihkan sesi pada browser/profile ini. Saat cookie auth Ello Store
// dihapus, tutup tab katalog-cookie dan hapus cookie hasil import pada browser ini saja.
if(chrome.cookies&&chrome.cookies.onChanged)chrome.cookies.onChanged.addListener(change=>{
  (async()=>{
    try{
      const c=change&&change.cookie;if(!c)return;
      const n=String(c.name||''),d=String(c.domain||'').replace(/^\./,'').toLowerCase();
      if(change.removed){
        if((d==='ellostoreapk.com'||d==='www.ellostoreapk.com')&&[ElloWebSession.names.id,ElloWebSession.names.refresh].includes(n)){
          // Chrome fires a removal with cause=overwrite when refreshing a cookie.
          // An actual logout is confirmed by checking both current website cookies.
          if(change.cause==='overwrite')return;
          await new Promise(resolve=>setTimeout(resolve,650));
          let session;
          try{session=await cookieStorage.get();}catch(_){return;} // A transient read failure is NOT logout.
          if(!session){
            await logGuardClose('WEBSITE_COOKIE_LOGOUT',0);
            await emergencyCleanupAll();
          }
        }
        return;
      }
      const active=await orionActiveSession();
      if(active&&active.host&&ElloCookies.inScope(d,String(active.host)))await clampOrionCookieLease(c,String(active.host));
    }catch(_){}
  })();
});
bootstrapCookieSafety().catch(()=>{});
try{if(chrome.storage&&chrome.storage.local&&chrome.storage.local.setAccessLevel)chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'}).catch(()=>{});if(chrome.storage&&chrome.storage.session&&chrome.storage.session.setAccessLevel)chrome.storage.session.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'}).catch(()=>{});}catch(_){}

function ready(){return initializing||(initializing=client.init());}
async function syncWebsiteSession(){const s=await cookieStorage.get();client.session=s;if(!s)return false;return true;}
async function assertWebsiteSession(){const s=await cookieStorage.get();if(!s||!client.session||s.uid!==client.session.uid){const e=new Error('Sesi website sudah berakhir. Masuk kembali melalui website.');e.code='SESSION_REVOKED';throw e;}}
function live(x){return !!x&&x.enabled===true&&Number.isFinite(x.expiresAt)&&x.expiresAt>=0&&(x.expiresAt===0||x.expiresAt>Date.now());}
function id(x){if(typeof x!=='string'||!x||/[.#$\[\]/]/.test(x)||x.length>128)throw new Error('Menu tidak valid.');return x;}
function maintenanceOn(m){return !!m&&m.enabled===true&&Date.now()>=Number(m.startAt)&&Date.now()<Number(m.endAt);}

async function getDeviceId(){
  if(deviceId)return deviceId;
  if(client.session&&/^[A-Za-z0-9_-]{20,128}$/.test(String(client.session.deviceId||'')))deviceId=String(client.session.deviceId);
  if(deviceId){await chrome.storage.local.set({elloDeviceId:deviceId});return deviceId;}
  const saved=await chrome.storage.local.get('elloDeviceId');
  deviceId=String(saved.elloDeviceId||'');
  if(!/^[A-Za-z0-9_-]{20,128}$/.test(deviceId)){
    const bytes=new Uint8Array(24);crypto.getRandomValues(bytes);
    deviceId=Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('');
    await chrome.storage.local.set({elloDeviceId:deviceId});
  }
  if(client.session){client.session.deviceId=deviceId;await cookieStorage.set(client.session);}
  return deviceId;
}
async function deviceState(forceClaim=false){
  const uid=client.session.uid,did=await getDeviceId(),path='activeSessions/'+uid,current=await client.db(path);
  if(forceClaim||!current){const stamp=Date.now();await client.db(path,'PUT',{deviceId:did,claimedAt:stamp,lastSeenAt:stamp,extensionVersion:LOCAL_VERSION,extensionVersionCode:LOCAL_VERSION_CODE});return true;}
  if(current.deviceId!==did)return false;
  const patch={};
  if(!Number.isFinite(current.lastSeenAt)||Date.now()-current.lastSeenAt>300000)patch.lastSeenAt=Date.now();
  if(String(current.extensionVersion||'')!==LOCAL_VERSION)patch.extensionVersion=LOCAL_VERSION;if(Number(current.extensionVersionCode)!==LOCAL_VERSION_CODE)patch.extensionVersionCode=LOCAL_VERSION_CODE;
  if(Object.keys(patch).length)await client.db(path,'PATCH',patch);
  return true;
}
async function assertDeviceActive(){if(!await deviceState(false)){const e=new Error('Akun aktif di perangkat lain. Tekan Periksa Login untuk memakai perangkat ini.');e.code='DEVICE_REVOKED';throw e;}}
let guardDeviceStateCache={key:'',at:0,ok:false};
async function assertDeviceActiveGuardCached(maxAge=30000){
 if(!client.session)throw Object.assign(new Error('Sesi website sudah berakhir.'),{code:'SESSION_REVOKED'});
 const did=await getDeviceId(),key=String(client.session.uid||'')+'|'+String(did||''),now=Date.now();
 if(guardDeviceStateCache.key===key&&now-Number(guardDeviceStateCache.at||0)<maxAge){
   if(!guardDeviceStateCache.ok)throw Object.assign(new Error('Akun aktif di perangkat lain. Tekan Periksa Login untuk memakai perangkat ini.'),{code:'DEVICE_REVOKED'});
   return true;
 }
 const ok=await deviceState(false);
 guardDeviceStateCache={key,at:now,ok:ok===true};
 if(!ok)throw Object.assign(new Error('Akun aktif di perangkat lain. Tekan Periksa Login untuk memakai perangkat ini.'),{code:'DEVICE_REVOKED'});
 return true;
}

async function account(){
  const profile=await client.db('users/'+client.session.uid);
  if(!ElloFirebase.hasEntitlement(profile))throw new Error('Paket Plus/Pro belum aktif atau masa akses berakhir.');
  const plan=await client.db('website/plans/'+(profile.planId||profile.plan),'GET',null,{public:true});
  if(!plan||!['plus','pro'].includes(plan.tier))throw new Error('Preset paket belum tersedia.');
  return{profile,plan};
}
async function gatewayAccess(menuId,itemId){
  const endpoint=String(ELLO_CONFIG.gatewayURL||'').replace(/\/+$/,'')+'/v1/access';
  if(!/^https:\/\/gateway\.ellostoreapk\.com\/v1\/access$/i.test(endpoint))throw new Error('Gateway Extension belum dikonfigurasi.');
  const did=await getDeviceId();
  const requestOnce=async(forceToken)=>{
    const token=await client.token(!!forceToken);
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),20000);
    try{
      const r=await fetch(endpoint,{
        method:'POST',
        headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json','Accept':'application/json'},
        body:JSON.stringify({menuId,itemId,deviceId:did,extensionVersion:LOCAL_VERSION,extensionVersionCode:LOCAL_VERSION_CODE}),
        cache:'no-store',
        signal:controller.signal,
        credentials:'omit',
        redirect:'error',
        referrerPolicy:'no-referrer'
      });
      let d={};try{d=await r.json();}catch(_){}
      if(r.status===401&&!forceToken)return requestOnce(true);
      if(!r.ok||!d||d.ok!==true){const e=new Error(String(d&&d.error||('Gateway gagal (HTTP '+r.status+').')));e.code=String(d&&d.code||'GATEWAY_ERROR');e.status=r.status;throw e;}
      return d;
    }catch(e){
      if(e&&e.name==='AbortError')throw new Error('Gateway melewati batas waktu. Coba lagi.');
      throw e;
    }finally{clearTimeout(timer);}
  };
  return requestOnce(false);
}
async function state(forceClaim=false,forceGlobal=false){
  if(!client.session){return{loggedIn:false};}
  if(!await deviceState(forceClaim)){
    const did=await getDeviceId();
    await cleanupOwnerLeases(client.session.uid,did,true);
    return{loggedIn:false,kicked:true};
  }
  let profile;
  try{
    profile=await client.db('users/'+client.session.uid);
  }catch(e){
    if(e.status===401){await cookieStorage.set(null);client.session=null;return{loggedIn:false};}
    throw e;
  }

  // Security/operational state tetap fresh:
  // profile, activeSessions, maintenance, release dan plan tidak memakai cache global.
  const [display,maintenance,release]=await Promise.all([
    globalDisplayConfig(forceGlobal),
    client.db('website/maintenance','GET',null,{public:true}),
    releaseInfo(forceGlobal)
  ]);
  const settings=display&&display.settings||{};
  const catalogCategories=display&&display.catalogCategories||{};
  const mustUpdate=updateRequired(release);
  const valid=ElloFirebase.hasEntitlement(profile);
  const plan=valid?await client.db('website/plans/'+(profile.planId||profile.plan),'GET',null,{public:true}):{};
  const allowed=plan&&plan.catalogs||{};

  let menus={},domains={},manualMenus={};
  if(valid&&!mustUpdate&&!maintenanceOn(maintenance)){
    const catalog=await globalCatalogStructure(forceGlobal);
    menus=catalog.menus||{};
    domains=catalog.domains||{};
    manualMenus=catalog.manualMenus||{};
  }

  menus=Object.fromEntries(
    Object.entries(menus||{})
      .filter(([key])=>allowed[key]&&allowed[key].enabled===true)
      .map(([key,m])=>[key,Object.assign({},m,{catalogType:'cookie'})])
  );
  manualMenus=Object.fromEntries(
    Object.entries(manualMenus||{})
      .filter(([key])=>allowed[key]&&allowed[key].enabled===true)
      .map(([key,m])=>[key,Object.assign({},m,{catalogType:'manual',maxDistinct:1,resetHours:0})])
  );
  menus=Object.assign({},menus,manualMenus);

  return{
    loggedIn:true,
    uid:client.session.uid,
    email:profile&&profile.email||client.session.email,
    profile,
    valid,
    planName:plan&&plan.name||profile.plan,
    settings,
    maintenance:maintenance||null,
    catalogCategories,
    menus,
    domains:domains||{},
    limits:allowed,
    extensionVersion:LOCAL_VERSION,
    extensionVersionCode:LOCAL_VERSION_CODE,
    latestVersion:String(release.version||''),
    releaseUpdatedAt:Number(release.updatedAt)||0,
    updateRequired:mustUpdate,
    updateUrl:String(release.downloadUrl||ELLO_CONFIG.website||'https://ellostoreapk.com')
  };
}
async function resolveOpenedTabId(openedTab,targetUrl){
  if(openedTab&&Number.isInteger(openedTab.id))return openedTab.id;
  try{
    const tabs=await chrome.tabs.query({active:true,currentWindow:true});
    if(Array.isArray(tabs)&&tabs.length){
      const exact=tabs.find(t=>Number.isInteger(t.id)&&String(t.url||'')===String(targetUrl||''));
      const first=exact||tabs.find(t=>Number.isInteger(t.id));
      if(first)return first.id;
    }
  }catch(_){}
  return 0;
}

async function runItemCore(menuId,itemId){
  menuId=id(menuId);itemId=id(itemId);
  {
    if(!client.session)throw new Error('Masuk melalui website terlebih dahulu.');
    await assertDeviceActive();
    await assertCurrentVersion();
    const [{plan},maintenance,menu,item,health,browserCfg]=await Promise.all([account(),client.db('website/maintenance','GET',null,{public:true}),client.db('extension/menus/'+menuId),client.db('extension/items/'+menuId+'/'+itemId),client.db('menuHealth/'+menuId+'/'+itemId),browserExtensionConfig()]);
    if(maintenanceOn(maintenance))throw new Error(maintenance.message||'Layanan sedang dalam pemeliharaan.');
    if(health&&health.down===true)throw new Error('Menu sedang diperbaiki Admin dan sementara tidak dapat digunakan.');
    if(!live(menu)||!live(item)||item.actionType!=='cookies')throw new Error('Menu tidak tersedia.');
    const grant=plan.catalogs&&plan.catalogs[menuId];if(!grant||grant.enabled!==true)throw new Error('Katalog tidak termasuk dalam paket Anda.');
    const limit=Math.min(Number(menu.maxDistinct)||0,Number(grant.maxDistinct)||0),windowMs=(Number(menu.resetHours)||0)*3600000;
    if(!Number.isInteger(limit)||limit<1||!Number.isInteger(windowMs)||windowMs<3600000)throw new Error('Preset batas menu belum valid.');
    const domain=await client.db('extension/domains/'+id(menu.domainId));
    if(!domain||domain.enabled!==true)throw new Error('Domain katalog tidak tersedia.');
    const preliminaryHost=ElloCookies.host(domain.host),origins=['https://'+preliminaryHost+'/*','https://*.'+preliminaryHost+'/*'];
    await assertExclusiveExtension(true);
    if(!await chrome.permissions.contains({origins:['<all_urls>']})&&!await chrome.permissions.contains({origins}))throw new Error('Izin seluruh situs belum diberikan. Buka Extension dan pilih Izinkan Seluruh Situs.');
    // Sensitive cookieSets + authoritative quota now come only from the Cloudflare gateway.
    const gateway=await gatewayAccess(menuId,itemId),payload=gateway&&gateway.payload,quota=gateway&&gateway.quota||{};
    const h=ElloCookies.host(gateway&&gateway.host);
    if(h!==preliminaryHost)throw new Error('Gateway mengembalikan domain yang tidak sesuai.');
    const url=ElloCookies.target(gateway&&gateway.url,h);
    if(!payload||payload.schemaVersion!==1||!Array.isArray(payload.cookies)||payload.cookies.length<1||payload.cookies.length>500)throw new Error('Data akses gateway belum tersedia.');
    const details=payload.cookies.map(c=>ElloCookies.setDetails(c,h));
    await assertWebsiteSession();await assertDeviceActive();
    const owner=await currentLeaseOwner();if(!owner)throw new Error('Sesi pengguna tidak tersedia.');
    const isOrionIOS=await orionIOSHost();
    // Browser lain mempertahankan perilaku lama (satu item aktif per katalog).
    // Orion iOS memakai satu sesi cookie global: membuka menu baru menutup sesi/tab cookie lama.
    if(isOrionIOS)await orionHardCleanupLocal(h);
    else await cleanupOwnerCatalogLeases(owner.uid,owner.deviceId,menuId,true);
    // Jika browser/profile ini sebelumnya dipakai akun lain, bersihkan residu lokalnya saja.
    // Ini tidak menyentuh browser/perangkat pengguna lain karena registry berada di storage extension lokal.
    await cleanupForeignLocalLeases(owner.uid,owner.deviceId);
    const leaseTtl=isOrionIOS?ORION_COOKIE_LEASE_SECONDS:COOKIE_LEASE_SECONDS;
    let count=0;const failures=[],cookieRefs=[];
    for(let i=0;i<details.length;i++){
      try{await assertWebsiteSession();const applied=await chrome.cookies.set(leaseSetDetails(details[i],leaseTtl));if(!applied)throw new Error('Browser menolak data akses.');count++;cookieRefs.push(cookieRefFromCookie(applied));}
      catch(e){failures.push({index:i+1,error:String(e.message||e).slice(0,240)});}
    }
    if(failures.length){for(const r of cookieRefs)await removeCookieRef(r);return{set:count,total:details.length,opened:false,failures,error:'Sebagian akses gagal disiapkan. Halaman tujuan belum dibuka.'};}
    const desktopMode=mobileExtensionHost()&&String(browserCfg&&browserCfg.mobileDefaultMode||'desktop').toLowerCase()!=='mobile';
    if(mobileExtensionHost())await setDesktopNetworkProfile(h,desktopMode);
    await assertWebsiteSession();await assertDeviceActive();let openedTab,openedTabId=0;try{openedTab=await chrome.tabs.create({url});openedTabId=await resolveOpenedTabId(openedTab,url);if(!Number.isInteger(openedTabId)||openedTabId<=0)throw new Error('Browser tidak memberikan ID tab akses.');await registerCookieLease(openedTabId,cookieRefs,{host:h,menuId,itemId,orionIos:isOrionIOS});if(isOrionIOS)await setOrionActiveSession({tabId:openedTabId,uid:owner.uid,deviceId:owner.deviceId,host:h,menuId,itemId,nonce:(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random()),createdAt:Date.now(),lastOkAt:Date.now()});if(isOrionIOS){await orionBound(armTabGuard(openedTabId,{uid:owner.uid,deviceId:owner.deviceId,ownerKey:owner.key,host:h,menuId,itemId,url,cookieRefs,desktopMode,orionIos:true}),2300,false);if(desktopMode)await orionBound(applyDesktopLayout(openedTabId),1000,false);}else{await armTabGuard(openedTabId,{uid:owner.uid,deviceId:owner.deviceId,ownerKey:owner.key,host:h,menuId,itemId,url,cookieRefs,desktopMode,orionIos:false});if(desktopMode)await applyDesktopLayout(openedTabId);await assertExclusiveExtension(true);}}catch(e){if(Number.isInteger(openedTabId)&&openedTabId>0)await cleanupCookieLeaseForTab(openedTabId,true);else for(const r of cookieRefs)await removeCookieRef(r);throw e;}
    return{set:count,total:details.length,opened:true,remaining:Number.isFinite(Number(quota.remaining))?Number(quota.remaining):0,resetAt:Number.isFinite(Number(quota.resetAt))?Number(quota.resetAt):0};
  }
}

function settleTask(p){
  return Promise.resolve(p).then(
    value=>({ok:true,value}),
    error=>({ok:false,error})
  );
}
async function runItem(menuId,itemId){
  const safeMenu=id(menuId),safeItem=id(itemId),key=safeMenu+'|'+safeItem;
  const isOrion=await orionIOSHost();

  // Chromium/Quetta retain the existing serialized behavior.
  // Orion iOS can leave an extension promise pending after a protected tab opens.
  // A fresh popup must not inherit that dead promise forever.
  if(runItemTask){
    if(!isOrion){
      if(runItemKey===key){
        const same=await settleTask(runItemTask);
        if(same.ok)return same.value;
        throw same.error;
      }
      await settleTask(runItemTask);
    }else{
      const age=Date.now()-Number(runItemTaskAt||0);
      const waited=await orionBound(settleTask(runItemTask),age>5000?350:1100,null);
      if(waited&&waited.ok&&runItemKey===key)return waited.value;

      // Fail closed before starting the replacement request:
      // wipe old shared cookies/session, then detach the stale Orion promise.
      await orionHardCleanupLocal();
      runItemTask=null;
      runItemKey='';
      runItemTaskAt=0;
    }
  }

  const task=runItemCore(safeMenu,safeItem);
  runItemTask=task;
  runItemKey=key;
  runItemTaskAt=Date.now();
  try{
    return await task;
  }finally{
    if(runItemTask===task){
      runItemTask=null;
      runItemKey='';
      runItemTaskAt=0;
    }
  }
}

async function manualItems(menuId){
 menuId=id(menuId);await assertDeviceActive();await assertCurrentVersion();const [{plan},maintenance,catalog,items]=await Promise.all([account(),client.db('website/maintenance','GET',null,{public:true}),client.db('manualCatalogs/'+menuId),client.db('manualCatalogItems/'+menuId)]);if(maintenanceOn(maintenance))throw new Error(maintenance.message||'Layanan sedang dalam pemeliharaan.');const grant=plan.catalogs&&plan.catalogs[menuId];if(!grant||grant.enabled!==true)throw new Error('Katalog tidak termasuk dalam paket Anda.');if(!live(catalog))throw new Error('Katalog login manual tidak tersedia.');const out={};for(const [itemId,it]of Object.entries(items||{}))if(it&&it.enabled!==false)out[itemId]=it;return out;
}
async function openManualItem(menuId,itemId){
 menuId=id(menuId);itemId=id(itemId);await assertDeviceActive();await assertCurrentVersion();const [{plan},maintenance,catalog,item]=await Promise.all([account(),client.db('website/maintenance','GET',null,{public:true}),client.db('manualCatalogs/'+menuId),client.db('manualCatalogItems/'+menuId+'/'+itemId)]);if(maintenanceOn(maintenance))throw new Error(maintenance.message||'Layanan sedang dalam pemeliharaan.');const grant=plan.catalogs&&plan.catalogs[menuId];if(!grant||grant.enabled!==true)throw new Error('Katalog tidak termasuk dalam paket Anda.');if(!live(catalog)||!live(item))throw new Error('Menu login manual tidak tersedia.');const url=String(ELLO_CONFIG.website||'https://ellostoreapk.com').replace(/\/$/,'')+'/#manual-login/'+encodeURIComponent(menuId)+'/'+encodeURIComponent(itemId);const tab=await chrome.tabs.create({url});return{opened:true,url,tabId:tab&&tab.id||0};
}
async function reportCookie(menuId,itemId){
 menuId=id(menuId);itemId=id(itemId);if(!client.session)throw new Error('Masuk melalui website terlebih dahulu.');await assertDeviceActive();await assertCurrentVersion();
 const [{profile},menu,item,rate]=await Promise.all([account(),client.db('extension/menus/'+menuId),client.db('extension/items/'+menuId+'/'+itemId),client.db('cookieReportRate/'+client.session.uid)]);
 if(!menu||!item)throw new Error('Menu tidak ditemukan.');
 const t=Date.now(),slots=['1','2','3'],rateData=rate||{},available=slots.find(k=>!rateData[k]||Number(rateData[k].createdAt||0)<=t-3600000);
 if(!available){const next=Math.min(...slots.map(k=>Number(rateData[k]&&rateData[k].createdAt||t)+3600000));const min=Math.max(1,Math.ceil((next-t)/60000));throw new Error('Batas laporan tercapai: maksimal 3 laporan dalam 1 jam. Coba lagi sekitar '+min+' menit.');}
 const reason='Pengguna melaporkan menu bermasalah dan meminta Admin melakukan pemeriksaan.',report={uid:client.session.uid,email:profile.email||client.session.email||'',menuId,itemId,menuTitle:String(menu.title||'Katalog'),itemName:String(item.itemName||'Menu'),reason,status:'pending',createdAt:t,updatedAt:t};
 await client.db('cookieReportRate/'+client.session.uid+'/'+available,'PUT',{createdAt:t,menuId,itemId});
 await client.db('cookieReports/'+menuId+'/'+itemId+'/'+client.session.uid,'PUT',report);
 const fresh=await client.db('cookieReportRate/'+client.session.uid)||{},used=slots.filter(k=>fresh[k]&&Number(fresh[k].createdAt||0)>t-3600000).length;
 return{reported:true,pendingAdmin:true,remaining:Math.max(0,3-used)};
}
async function route(m){
  await ready();await syncUrlGuardRules(false);
  if(!await syncWebsiteSession()){await emergencyCleanupAll();if(m.type==='STATE'||m.type==='CLAIM_DEVICE')return{loggedIn:false};throw new Error('Masuk melalui ellostoreapk.com terlebih dahulu.');}
  switch(m.type){
    case'STATE':return state(false,false);
    case'REFRESH_STATE':
      releaseCache=null;releaseCacheAt=0;
      await clearGlobalConfigCache();
      await syncUrlGuardRules(true);
      return state(false,true);
    case'CLAIM_DEVICE':
      guardDeviceStateCache={key:'',at:0,ok:false};
      return state(true,false);
    case'ITEMS':{
      await assertDeviceActive();await assertCurrentVersion();
      const menuId=id(m.menuId);
      // 2 read saja berapa pun jumlah item:
      // 1) semua item katalog, 2) seluruh health map katalog.
      const [items,healthMapRaw]=await Promise.all([
        client.db('extension/items/'+menuId),
        client.db('menuHealth/'+menuId)
      ]);
      const healthMap=healthMapRaw&&typeof healthMapRaw==='object'?healthMapRaw:{},out={};
      for(const [itemId,it] of Object.entries(items||{})){
        const health=healthMap[itemId],down=health&&health.down===true;
        out[itemId]=Object.assign({},it,{
          temporaryUnavailable:down,
          healthReason:down?String(health.reason||'Sedang diperbaiki Admin.'):''
        });
      }
      return out;
    }
    case'MANUAL_ITEMS':return manualItems(m.menuId);
    case'OPEN_MANUAL_ITEM':return openManualItem(m.menuId,m.itemId);
    case'RUN_ITEM':return runItem(m.menuId,m.itemId);
    case'REPORT_COOKIE':return reportCookie(m.menuId,m.itemId);
    default:throw new Error('Pesan extension tidak dikenali.');
  }
}
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
  if(sender.id&&sender.id!==chrome.runtime.id)return false;
  if(m&&m.type==='ORION_GUARD_PING'&&sender.tab&&Number.isInteger(sender.tab.id)){
    if(sender.frameId!==0)return false;
    getTabGuard(sender.tab.id).then(async g=>{
      if(!g||g.orionIos!==true)return respond({ok:false});
      try{
        const u=new URL(String(m.href||sender.url||sender.tab.url||''));
        if(u.protocol!=='https:'||!ElloCookies.inScope(u.hostname,g.host))throw Object.assign(new Error('scope'),{code:'DOMAIN_VIOLATION'});
        if(!await syncWebsiteSession())throw Object.assign(new Error('Logout website'),{code:'SESSION_REVOKED'});await assertWebsiteSession();await assertDeviceActive();
        const owner=await currentLeaseOwner();
        if(!owner||!sameLeaseOwner(g,owner.uid,owner.deviceId))throw Object.assign(new Error('owner'),{code:'DEVICE_REVOKED'});
        const active=await orionActiveSession();
        if(!active||Number(active.tabId)!==Number(sender.tab.id)||String(active.host)!==String(g.host))throw Object.assign(new Error('inactive'),{code:'DEVICE_REVOKED'});
        active.lastOkAt=Date.now();
        await setOrionActiveSession(active);
        await refreshCookieLeaseForTab(sender.tab.id,false);
        respond({ok:true,host:String(active.host),lastOkAt:active.lastOkAt});
      }catch(e){
        const definite=e&&['DOMAIN_VIOLATION','DEVICE_REVOKED','SESSION_REVOKED','EXTENSION_CONFLICT'].includes(e.code);
        if(definite){
          await logGuardClose(e.code,sender.tab.id);
          try{await orionWipeHostCookies(g.host);}catch(__){}
          cleanupCookieLeaseForTab(sender.tab.id,true).catch(()=>{});
          respond({ok:false});
        }else respond({ok:null,retry:true});
      }
    }).catch(()=>respond({ok:null,retry:true}));
    return true;
  }
  if(m&&m.type==='TAB_GUARD_PING'&&sender.tab&&Number.isInteger(sender.tab.id)){
    if(sender.frameId!==0)return false;
    getTabGuard(sender.tab.id).then(async g=>{
      if(!g||g.token!==m.token){await logGuardClose('GUARD_TOKEN_MISMATCH',sender.tab.id);return respond({ok:false});}
      try{
        const u=new URL(String(sender.url||sender.tab.url||''));
        if(u.protocol!=='https:'||!ElloCookies.inScope(u.hostname,g.host))throw Object.assign(new Error('Tab keluar domain.'),{code:'DOMAIN_VIOLATION'});
        await assertExclusiveExtension(false);
        if(!await syncWebsiteSession())throw Object.assign(new Error('Logout website.'),{code:'SESSION_REVOKED'});
        await assertWebsiteSession();await assertDeviceActive();
        const owner=await currentLeaseOwner();
        if(!owner||!sameLeaseOwner(g,owner.uid,owner.deviceId))throw Object.assign(new Error('Perangkat berubah.'),{code:'DEVICE_REVOKED'});
        refreshCookieLeaseForTab(sender.tab.id,false).catch(()=>{});
        respond({ok:true});
      }catch(e){
        if(e&&['DOMAIN_VIOLATION','DEVICE_REVOKED','SESSION_REVOKED','EXTENSION_CONFLICT'].includes(e.code)){
          await logGuardClose(e.code,sender.tab.id);
          cleanupCookieLeaseForTab(sender.tab.id,true).catch(()=>{});
          respond({ok:false,reason:e.code});
        }else{
          // Do not clear cookies for a transient Firebase/extension message failure.
          // The isolated page fails closed after 12 seconds without a valid reply.
          respond({ok:null,retry:true});
        }
      }
    }).catch(()=>respond({ok:null,retry:true}));return true;
  }
  if(sender.url!==chrome.runtime.getURL('popup.html'))return false;
  route(m||{}).then(data=>respond({ok:true,data}),e=>respond({ok:false,error:String(e.message||e),code:String(e&&e.code||'')}));return true;
});

// Orion iOS event-page wake reconciliation. Chromium/Quetta path is unchanged.
orionResumeSweep().catch(()=>{});
