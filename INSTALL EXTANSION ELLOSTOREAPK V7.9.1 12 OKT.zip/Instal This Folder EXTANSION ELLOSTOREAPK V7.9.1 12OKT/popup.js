'use strict';
const $=id=>document.getElementById(id);
// R6.14.2U — Browser permission remains OPTIONAL until the user explicitly approves it.
// The call to permissions.request MUST run directly from a button/item click (user gesture).
const ALL_SITES_ORIGINS=['<all_urls>'];
let allSitesGranted=false;
function paintAllSitesPermission(){
 const panel=$('siteAccessBox');
 if(panel)panel.hidden=allSitesGranted;
}
async function refreshAllSitesPermission(){
 try{allSitesGranted=!!(chrome.permissions&&chrome.permissions.contains&&await chrome.permissions.contains({origins:ALL_SITES_ORIGINS}));}
 catch(_){allSitesGranted=false;}
 paintAllSitesPermission();
 return allSitesGranted;
}
function requestAllSitesFromGesture(){
 if(!chrome.permissions||typeof chrome.permissions.request!=='function')throw new Error('Browser belum mendukung dialog izin seluruh situs. Periksa pengaturan akses situs Extension.');
 // No await, no messaging, and no storage operation before this call.
 return chrome.permissions.request({origins:ALL_SITES_ORIGINS});
}

// Orion resmi menyediakan window.KAGI sebagai penanda konteks browser.
// Jangan bergantung pada navigator.userAgent: Orion iOS dapat memakai Desktop Site / custom User Agent,
// sehingga string iPhone/iPad dapat hilang dan jalur Orion salah dianggap sebagai Chromium biasa.
const ORION_IOS_CONTEXT=!!globalThis.KAGI;
try{
 const profile={enabled:ORION_IOS_CONTEXT,at:Date.now(),detectedBy:ORION_IOS_CONTEXT?'window.KAGI':'none',capabilities:{tabs:!!chrome.tabs,cookies:!!chrome.cookies,alarms:!!chrome.alarms,webNavigation:!!chrome.webNavigation,scripting:!!chrome.scripting,dnr:!!chrome.declarativeNetRequest,management:!!chrome.management}};
 chrome.storage.local.set({elloOrionIOSContext:profile,elloOrionPopupRoute:{route:(ORION_IOS_CONTEXT&&globalThis.ElloOrionDirect)?'direct':'background',at:Date.now()}}).catch(()=>{});
}catch(_){}
let current=null,busy=false,last={lastCatalogId:'',items:{}},reportContext=null,itemHealthTimer=null,currentItemsView=null,currentReportItems={},activeCategory='all',catalogSearchText='',noticeMenuId='',noticeMenuVersion=0;
const date=n=>n?new Date(n).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})+' WIB':'Tanpa batas';
function msg(text,bad=false){$('message').textContent=text||'';$('message').className='message'+(bad?' bad':'');}
async function send(type,data={}){let timer;try{const r=await Promise.race([chrome.runtime.sendMessage(Object.assign({type},data)),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Layanan belum merespons. Buka ulang popup.')),90000);})]);if(!r||!r.ok){const e=new Error(r&&r.error||'Layanan belum merespons. Buka ulang extension.');if(r&&r.code)e.code=r.code;throw e;}return r.data;}catch(e){if(/Receiving end|Could not establish connection/i.test(e.message))throw new Error('Extension perlu dimuat ulang melalui halaman Extensions.');throw e;}finally{clearTimeout(timer);}}
function node(tag,text,cls){const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;}
function live(m){return m&&m.enabled===true&&typeof m.expiresAt==='number'&&(m.expiresAt===0||m.expiresAt>Date.now());}
function icon(url,label){const holder=node('span',null,'catalogIcon'),fallback=()=>{holder.replaceChildren();holder.textContent=(label||'E').slice(0,1).toUpperCase();};if(!url){fallback();return holder;}try{const u=new URL(url);if(u.protocol!=='https:'||u.username||u.password||url.length>2048){fallback();return holder;}const img=node('img');img.src=u.href;img.alt='';img.referrerPolicy='no-referrer';img.onerror=fallback;holder.append(img);}catch(_){fallback();}return holder;}
function tile(url,label,detail,selected){const b=node('button',null,'iconTile'+(selected?' lastClick':''));b.type='button';b.title=label+' · '+detail;b.setAttribute('aria-label',label+' · '+detail);b.append(icon(url,label),node('span',label,'visuallyHidden'),node('span',detail,'visuallyHidden'));return b;}
function clearCookieReport(){reportContext=null;currentReportItems={};$('cookieReportBox').hidden=true;$('openReport').hidden=true;$('reportCookie').disabled=false;$('reportCookie').textContent='Kirim Laporan';const sel=$('reportMenuSelect');if(sel)sel.replaceChildren();}
function prepareManualReport(menuId,items){currentReportItems=items||{};const sel=$('reportMenuSelect');sel.replaceChildren();for(const [itemId,it] of Object.entries(currentReportItems)){if(it&&it.temporaryUnavailable!==true&&it.enabled!==false){const o=document.createElement('option');o.value=itemId;o.textContent=it.itemName||'Menu';sel.append(o);}}$('openReport').hidden=!sel.options.length;$('openReport').dataset.menuId=menuId;$('cookieReportBox').hidden=true;reportContext=null;}
function openManualReport(){const menuId=$('openReport').dataset.menuId,itemId=$('reportMenuSelect').value,it=currentReportItems[itemId];if(!menuId||!itemId||!it)throw new Error('Pilih menu yang ingin dilaporkan.');reportContext={menuId,itemId,itemName:it.itemName||'Menu'};$('cookieReportBox').hidden=false;}
async function draw(state){
 current=state;clearCookieReport();$('loginView').hidden=state.loggedIn;$('accountView').hidden=!state.loggedIn;
 if(!state.loggedIn){stopItemHealthPolling();if(state.kicked)msg('Sesi Anda telah dipindahkan ke perangkat lain.',true);return;}
 const box=$('updateBox');box.hidden=!state.updateRequired;if(state.updateRequired){$('updateText').textContent='Versi terpasang V'+(state.extensionVersion||chrome.runtime.getManifest().version)+' sudah tidak dapat mengakses katalog. Update wajib ke V'+(state.latestVersion||'terbaru')+'.';$('updateDate').textContent=state.releaseUpdatedAt?'Update Admin: '+new Date(state.releaseUpdatedAt).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})+' WIB':'';$('updateExtension').href=/^https:\/\//i.test(state.updateUrl||'')?state.updateUrl:'https://ellostoreapk.com/#akun';}
 last=(await chrome.storage.local.get('lastClick_'+state.uid))['lastClick_'+state.uid]||{lastCatalogId:'',items:{}};
 if(!last.items)last={lastCatalogId:last.catalogId||'',items:last.catalogId&&last.itemId?{[last.catalogId]:last.itemId}:{}};
 const p=state.profile||{},tier=String(p.plan||'').toLowerCase();$('accountEmail').textContent=state.email;$('plan').textContent=state.valid?tier.toUpperCase():'PILIH PAKET';$('plan').className='badge'+(state.valid&&tier==='plus'?' plus':state.valid&&tier==='pro'?' pro':'');$('expiry').textContent=state.valid?'Aktif sampai '+date(p.expiresAt):'Pilih Plus atau Pro melalui website';
 const maintenance=state.maintenance&&state.maintenance.enabled&&Date.now()>=state.maintenance.startAt&&Date.now()<state.maintenance.endAt;$('notice').hidden=!state.settings.notice&&!maintenance;$('notice').textContent=maintenance?(state.maintenance.message||'Layanan sedang dalam perawatan.'):state.settings.notice||'';if(state.updateRequired){$('menus').replaceChildren(node('p','Update extension terlebih dahulu. Katalog dikunci sampai versi terbaru dipasang.','empty'));$('listTitle').textContent='Update diperlukan';$('back').hidden=true;$('ticker').hidden=true;$('hint').textContent='';msg('Extension lama diblokir. Silakan update melalui tombol di atas.',true);}else drawCatalogs();
}
function stopItemHealthPolling(){if(itemHealthTimer){clearInterval(itemHealthTimer);itemHealthTimer=null;}currentItemsView=null;}
function scheduleItemHealthPolling(menuId,menu,domain){
 stopItemHealthPolling();
 // Hemat usage: simpan konteks saja. Status item diambil saat menu dibuka
 // atau saat pengguna menekan Refresh, bukan polling server tiap 5 detik.
 currentItemsView={menuId,menu,domain};
}
function categoryName(id){const c=current&&current.catalogCategories&&current.catalogCategories[id];return c&&c.name?String(c.name):'';}
function visibleCatalogs(){const q=String(catalogSearchText||'').trim().toLocaleLowerCase('id-ID');return Object.entries(current&&current.menus||{}).filter(([,m])=>{if(activeCategory!=='all'&&String(m.categoryId||'')!==activeCategory)return false;if(!q)return true;return String(m.title||'').toLocaleLowerCase('id-ID').includes(q)||categoryName(m.categoryId).toLocaleLowerCase('id-ID').includes(q);}).sort((a,b)=>(a[1].order||0)-(b[1].order||0));}
function drawCategoryTools(){const holder=$('catalogCategories');if(!holder)return;holder.replaceChildren();const menus=Object.values(current&&current.menus||{}),cats=Object.entries(current&&current.catalogCategories||{}).filter(([,c])=>c&&c.enabled!==false).sort((a,b)=>(Number(a[1].order)||0)-(Number(b[1].order)||0));if(activeCategory!=='all'&&!cats.some(([id])=>id===activeCategory))activeCategory='all';const all=node('button','Semua','categoryChip'+(activeCategory==='all'?' active':''));all.type='button';all.onclick=()=>{activeCategory='all';drawCatalogs();};holder.append(all);for(const [id,c] of cats){if(!menus.some(m=>String(m.categoryId||'')===id))continue;const b=node('button',String(c.name||'Kategori'),'categoryChip'+(activeCategory===id?' active':''));b.type='button';b.onclick=()=>{activeCategory=id;drawCatalogs();};holder.append(b);}}
async function maybeShowCatalogNotice(menuId,menu){if(!menu||menu.popupNoticeEnabled!==true)return;const title=String(menu.popupNoticeTitle||'Informasi '+(menu.title||'Katalog')).trim(),text=String(menu.popupNoticeText||'').trim();if(!text)return;const version=Number(menu.updatedAt)||Number(menu.version)||0,key='catalogNoticeMute_'+String(current.uid)+'_'+menuId,stored=(await chrome.storage.local.get(key))[key];if(stored&&Number(stored.until)>Date.now()&&Number(stored.version)===version)return;noticeMenuId=menuId;noticeMenuVersion=version;$('catalogNoticeTitle').textContent=title;$('catalogNoticeText').textContent=text;$('catalogNoticeMute').checked=false;$('catalogNoticeModal').hidden=false;}
async function closeCatalogNotice(){if($('catalogNoticeMute').checked&&noticeMenuId&&current&&current.uid){const key='catalogNoticeMute_'+String(current.uid)+'_'+noticeMenuId;await chrome.storage.local.set({[key]:{until:Date.now()+86400000,version:noticeMenuVersion}});}$('catalogNoticeModal').hidden=true;noticeMenuId='';noticeMenuVersion=0;}
function drawCatalogs(){
 stopItemHealthPolling();
 const w=$('menus');w.replaceChildren();clearCookieReport();$('back').hidden=true;$('listTitle').textContent='Katalog';$('ticker').hidden=true;$('hint').textContent='';$('catalogTools').hidden=false;drawCategoryTools();
 const list=visibleCatalogs();if(!list.length)w.append(node('p',current.valid?(catalogSearchText||activeCategory!=='all'?'Katalog tidak ditemukan pada filter ini.':'Belum ada katalog yang tersedia untuk paket ini.'):'Masa akses sudah berakhir. Pilih paket di website.','empty'));
 const grid=node('div',null,'iconGrid');
 for(const [key,m]of list){const manual=m.catalogType==='manual',d=current.domains[m.domainId]||{},active=live(m)&&(manual||d.enabled===true),detail=manual?((m.itemCount||0)+' pilihan login manual · '+(active?'Tersedia':'Tidak aktif')):((m.itemCount||0)+' pilihan · batas '+Math.min(Number(m.maxDistinct)||0,Number(current.limits&&current.limits[key]&&current.limits[key].maxDistinct)||0)+' per '+(m.resetHours||'?')+' jam · '+(active?'Tersedia':'Tidak aktif'));const card=tile(m.iconUrl,m.title||'Katalog',detail,last.lastCatalogId===key);card.disabled=!active||!current.valid;card.onclick=()=>guard(async()=>{last.lastCatalogId=key;last.at=Date.now();await chrome.storage.local.set({['lastClick_'+current.uid]:last});if(manual)await drawManualItems(key,m);else await drawItems(key,m,d);await maybeShowCatalogNotice(key,m);});grid.append(card);}w.append(grid);
}
async function drawItems(menuId,menu,domain,autoRefresh=false){
 const items=(ORION_IOS_CONTEXT&&globalThis.ElloOrionDirect)?await globalThis.ElloOrionDirect.getItems(menuId):await send('ITEMS',{menuId}),w=$('menus');w.replaceChildren();$('catalogTools').hidden=true;$('back').hidden=false;$('listTitle').textContent='Pilihan akses';$('hint').textContent='';$('ticker').hidden=!menu.tickerText;$('tickerText').textContent=menu.tickerText||'';const grid=node('div',null,'iconGrid');
 for(const [itemId,it]of Object.entries(items||{})){const down=it.temporaryUnavailable===true,active=live(it)&&it.actionType==='cookies'&&!down,card=tile(it.iconUrl,it.itemName||'Layanan',it.url+' · '+(down?'Sedang diperbaiki Admin':(active?'Tersedia':'Tidak aktif')),last.items&&last.items[menuId]===itemId);card.classList.add('itemTile');card.append(node('span',it.itemName||'Menu','itemTileName'));if(down){card.classList.add('temporarilyDown');card.append(node('span','PERBAIKAN','tileState'));}card.disabled=!active;card.onclick=async()=>{if(busy)return;busy=true;card.disabled=true;try{
 // Trigger the ONE global browser consent dialog on first catalog access (before awaits).
 if(!allSitesGranted){
   const approved=await requestAllSitesFromGesture();
   if(!approved)throw new Error('Akses seluruh situs belum diizinkan. Klik Izinkan Seluruh Situs di bagian atas untuk mencoba lagi.');
   allSitesGranted=true;paintAllSitesPermission();
 }
 // If the user revoked the permission while this popup was open, fail safely.
 if(!await refreshAllSitesPermission())throw new Error('Izin seluruh situs sudah dicabut. Izinkan kembali sebelum membuka katalog.');
 last.lastCatalogId=menuId;last.items=last.items||{};last.items[menuId]=itemId;last.at=Date.now();await chrome.storage.local.set({['lastClick_'+current.uid]:last});w.querySelectorAll('.iconTile').forEach(x=>x.classList.remove('lastClick'));card.classList.add('lastClick');msg('Menyiapkan akses…');
 const result=(ORION_IOS_CONTEXT&&globalThis.ElloOrionDirect)?await globalThis.ElloOrionDirect.runItem(menuId,itemId):await send('RUN_ITEM',{menuId,itemId});if(result&&result.error)throw new Error(result.error);msg('Akses siap. Halaman tujuan dibuka.');
 }catch(e){msg(e&&e.message||'Gagal meminta izin situs.',true);}finally{busy=false;card.disabled=!active;}};grid.append(card);}
 if(!Object.keys(items||{}).length)w.append(node('p','Belum ada pilihan tersedia.','empty'));w.append(grid);prepareManualReport(menuId,items);scheduleItemHealthPolling(menuId,menu,domain);
}

async function drawManualItems(menuId,menu){
 stopItemHealthPolling();clearCookieReport();const items=await send('MANUAL_ITEMS',{menuId}),w=$('menus');w.replaceChildren();$('catalogTools').hidden=true;$('back').hidden=false;$('listTitle').textContent='Pilihan login manual';$('hint').textContent='Klik menu untuk membuka halaman login manual di ellostoreapk.com.';$('ticker').hidden=true;const grid=node('div',null,'iconGrid');
 for(const [itemId,it]of Object.entries(items||{}).sort((a,b)=>(Number(a[1].order)||0)-(Number(b[1].order)||0))){const active=live(it),card=tile(it.iconUrl,it.itemName||'Layanan','Login manual · '+(it.credentialCount||0)+' akun · '+(active?'Tersedia':'Tidak aktif'),last.items&&last.items[menuId]===itemId);card.classList.add('itemTile');card.append(node('span',it.itemName||'Menu','itemTileName'));card.disabled=!active;card.onclick=()=>guard(async()=>{last.lastCatalogId=menuId;last.items=last.items||{};last.items[menuId]=itemId;last.at=Date.now();await chrome.storage.local.set({['lastClick_'+current.uid]:last});w.querySelectorAll('.iconTile').forEach(x=>x.classList.remove('lastClick'));card.classList.add('lastClick');msg('Membuka halaman login manual…');await send('OPEN_MANUAL_ITEM',{menuId,itemId});msg('Halaman login manual dibuka di tab baru.');});grid.append(card);}if(!Object.keys(items||{}).length)w.append(node('p','Belum ada pilihan login manual.','empty'));w.append(grid);
}
async function guard(action){if(busy)return;busy=true;try{await action();}catch(e){msg(e.message,true);}finally{busy=false;}}
$('openReport').onclick=()=>guard(async()=>{openManualReport();});$('cancelReport').onclick=()=>{$('cookieReportBox').hidden=true;reportContext=null;};$('reportMenuSelect').onchange=()=>{if(!$('cookieReportBox').hidden)openManualReport();};
$('reportCookie').onclick=()=>guard(async()=>{openManualReport();const ctx={...reportContext},result=await send('REPORT_COOKIE',ctx);msg('Laporan dikirim dan menunggu konfirmasi Admin. Menu masih dapat digunakan sampai Admin menyatakan menu benar-benar bermasalah.'+(result&&Number.isFinite(result.remaining)?' Sisa laporan 1 jam ini: '+result.remaining+'.':''));$('cookieReportBox').hidden=true;reportContext=null;});
// Optional permission prompt is initiated by the real user click, never silently on install.
$('grantAllSites').onclick=()=>{
 const button=$('grantAllSites');button.disabled=true;
 let request;
 try{request=requestAllSitesFromGesture();}
 catch(e){button.disabled=false;msg(e.message,true);return;}
 Promise.resolve(request).then(async approved=>{
   await refreshAllSitesPermission();
   if(!approved||!allSitesGranted)throw new Error('Akses seluruh situs belum disetujui. Katalog tetap memerlukan izin ini.');
   msg('Izin seluruh situs aktif. Semua katalog dapat dibuka tanpa permintaan izin domain tambahan.');
 }).catch(e=>msg(e&&e.message||'Permintaan izin situs gagal.',true))
 .finally(()=>{button.disabled=false;});
};
if(chrome.permissions&&chrome.permissions.onAdded)chrome.permissions.onAdded.addListener(()=>{refreshAllSitesPermission().catch(()=>{});});
if(chrome.permissions&&chrome.permissions.onRemoved)chrome.permissions.onRemoved.addListener(()=>{refreshAllSitesPermission().catch(()=>{});});
// Check existing approval at startup; no permission dialog unless the user acts.
refreshAllSitesPermission().catch(()=>{});
$('checkLogin').onclick=()=>guard(async()=>{await draw(await send('CLAIM_DEVICE'));msg(current.loggedIn?'Perangkat ini sekarang aktif.':'Belum masuk di website.');});
$('refresh').onclick=()=>guard(async()=>{
 const view=currentItemsView?{...currentItemsView}:null;
 await draw(await send('REFRESH_STATE'));
 if(view&&current&&current.loggedIn&&current.menus&&current.menus[view.menuId]){
   const freshMenu=current.menus[view.menuId],freshDomain=current.domains&&current.domains[freshMenu.domainId]||view.domain;
   if(freshMenu.catalogType==='cookie'&&freshDomain)await drawItems(view.menuId,freshMenu,freshDomain,true);
 }
 msg('Semua informasi terbaru sudah diperiksa.');
});
$('back').onclick=()=>drawCatalogs();
$('catalogSearch').addEventListener('input',e=>{catalogSearchText=String(e.target.value||'');if(current&&current.loggedIn)drawCatalogs();});
$('closeCatalogNotice').onclick=()=>guard(closeCatalogNotice);
$('catalogNoticeModal').addEventListener('click',e=>{if(e.target===$('catalogNoticeModal'))guard(closeCatalogNotice);});
guard(async()=>draw(await send('STATE')));


// Production UI hardening: deters casual inspection only; authorization remains server-side.
document.addEventListener('contextmenu',e=>e.preventDefault(),true);
document.addEventListener('keydown',e=>{
  const k=String(e.key||'').toLowerCase();
  if(e.key==='F12'||(e.ctrlKey&&k==='u')||(e.ctrlKey&&e.shiftKey&&['i','j','c'].includes(k))){e.preventDefault();e.stopPropagation();}
},true);
