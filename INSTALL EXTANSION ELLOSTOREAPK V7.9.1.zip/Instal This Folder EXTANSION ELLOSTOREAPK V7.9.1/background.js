'use strict';
importScripts('config.js','firebase.js','cookies.js','web-session.js');

const SITE='https://ellostoreapk.com/';
const cookieStorage={
  get:async()=>{
    const [a,b,d,r]=await Promise.all([
      chrome.cookies.get({url:SITE,name:ElloWebSession.names.id}),
      chrome.cookies.get({url:SITE,name:ElloWebSession.names.refresh}),
      chrome.cookies.get({url:SITE,name:ElloWebSession.names.device}),
      chrome.cookies.get({url:SITE,name:ElloWebSession.names.remember})
    ]);
    if(!a||!b)return null;
    try{return ElloWebSession.fromTokens(
      decodeURIComponent(a.value),
      decodeURIComponent(b.value),
      d?decodeURIComponent(d.value):'',
      !!(r&&decodeURIComponent(r.value)==='1')
    );}catch(_){return null;}
  },
  set:async s=>{
    if(!s){
      await Promise.all([
        chrome.cookies.remove({url:SITE,name:ElloWebSession.names.id}),
        chrome.cookies.remove({url:SITE,name:ElloWebSession.names.refresh}),
        chrome.cookies.remove({url:SITE,name:ElloWebSession.names.device}),
        chrome.cookies.remove({url:SITE,name:ElloWebSession.names.remember})
      ]);
      return;
    }
    const expiry=Math.floor(Date.now()/1000)+2592000,remember=s.remember===true;
    for(const [name,value] of [
      [ElloWebSession.names.refresh,s.refreshToken],
      [ElloWebSession.names.id,s.idToken],
      [ElloWebSession.names.device,s.deviceId||''],
      [ElloWebSession.names.remember,remember?'1':'0']
    ]){
      const details={url:SITE,name,value:encodeURIComponent(value),domain:'ellostoreapk.com',path:'/',secure:true,httpOnly:true,sameSite:'strict'};
      if(remember)details.expirationDate=expiry;
      const c=await chrome.cookies.set(details);
      if(!c)throw new Error('Sesi website tidak dapat diperbarui.');
    }
  }
};
const client=new ElloFirebase.Client(ELLO_CONFIG,cookieStorage);
let initializing,running=false,deviceId='',releaseCache=null,releaseCacheAt=0;
const LOCAL_VERSION=chrome.runtime.getManifest().version;
function versionParts(v){return String(v||'').replace(/^v/i,'').split('.').slice(0,4).map(x=>parseInt(x,10)||0);}
function versionCode(v){const p=versionParts(v);return (p[0]||0)*10000+(p[1]||0)*100+(p[2]||0);}
const LOCAL_VERSION_CODE=versionCode(LOCAL_VERSION);
function compareVersion(a,b){const x=versionParts(a),y=versionParts(b),n=Math.max(x.length,y.length,3);for(let i=0;i<n;i++){const d=(x[i]||0)-(y[i]||0);if(d)return d>0?1:-1;}return 0;}
async function releaseInfo(force=false){if(!force&&releaseCache&&Date.now()-releaseCacheAt<30000)return releaseCache;releaseCache=await client.db('website/extensionRelease','GET',null,{public:true})||{};releaseCacheAt=Date.now();return releaseCache;}
function updateRequired(r){const requiredCode=Number(r&&r.versionCode)||versionCode(r&&r.version);if(requiredCode>0)return LOCAL_VERSION_CODE<requiredCode;const latest=String(r&&r.version||'').trim();return !!latest&&compareVersion(LOCAL_VERSION,latest)<0;}
async function assertCurrentVersion(){const r=await releaseInfo();if(updateRequired(r)){const e=new Error('Extension V'+LOCAL_VERSION+' sudah lama. Wajib update ke V'+r.version+' melalui website Ello Store.');e.code='UPDATE_REQUIRED';throw e;}return r;}

const URL_GUARD_RULE_BASE=8700000,URL_GUARD_SYNC_MINUTES=1;let urlGuardCache=[],urlGuardSyncedAt=0;
function escapeRe(s){return String(s).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function normalizeGuardUrl(raw){try{const u=new URL(String(raw||''));if(u.protocol!=='https:'&&u.protocol!=='http:')return'';return u.href;}catch(_){return'';}}
function guardMatches(g,raw){const u=normalizeGuardUrl(raw),base=normalizeGuardUrl(g&&g.url);if(!u||!base)return false;if(g.match==='exact')return u===base;if(g.match==='suffix'){try{const cur=new URL(u),rule=new URL(base);if(cur.origin!==rule.origin)return false;const suffix=rule.hash||(rule.pathname&&rule.pathname!=='/'?rule.pathname+rule.search:rule.search);return !!suffix&&u.endsWith(suffix);}catch(_){return false;}}return u.startsWith(base);}
function guardRuleId(key,index){let h=2166136261;for(const c of String(key)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return URL_GUARD_RULE_BASE+((h>>>0)%900000)+index%97;}
function dnrRegex(g){const base=normalizeGuardUrl(g.url);if(!base)return'';const u=new URL(base);if(u.hash||g.match==='suffix')return'';const escaped=escapeRe(base);return g.match==='exact'?'^'+escaped+'$':'^'+escaped+'.*';}
async function loadUrlGuards(force=false){if(!force&&urlGuardCache.length&&Date.now()-urlGuardSyncedAt<45000)return urlGuardCache;let data={};try{data=await client.db('website/urlGuards','GET',null,{public:true})||{};}catch(_){return urlGuardCache;}urlGuardCache=Object.entries(data).filter(([,x])=>x&&x.enabled!==false&&normalizeGuardUrl(x.url)).sort((a,b)=>(Number(a[1].order)||0)-(Number(b[1].order)||0)).map(([id,x])=>({id,name:String(x.name||'URL diblokir').slice(0,120),url:normalizeGuardUrl(x.url),match:x.match==='exact'?'exact':(x.match==='suffix'?'suffix':'prefix'),action:x.action==='close'?'close':'back'}));urlGuardSyncedAt=Date.now();return urlGuardCache;}
async function syncUrlGuardRules(force=false){const rows=await loadUrlGuards(force);const old=await chrome.declarativeNetRequest.getDynamicRules(),removeRuleIds=old.filter(r=>r.id>=URL_GUARD_RULE_BASE&&r.id<URL_GUARD_RULE_BASE+1000000).map(r=>r.id),used=new Set(),addRules=[];for(let i=0;i<rows.length;i++){const g=rows[i],regex=dnrRegex(g);if(!regex)continue;let id=guardRuleId(g.id,i);while(used.has(id))id++;used.add(id);addRules.push({id,priority:1000+i,action:{type:'block'},condition:{regexFilter:regex,resourceTypes:['main_frame']}});}try{await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds,addRules});await chrome.storage.local.set({elloUrlGuards:rows,elloUrlGuardsAt:Date.now()});}catch(e){console.warn('URL Guard rules gagal disinkronkan',e);}return rows;}
async function cachedUrlGuards(){if(urlGuardCache.length)return urlGuardCache;const x=await chrome.storage.local.get('elloUrlGuards');urlGuardCache=Array.isArray(x.elloUrlGuards)?x.elloUrlGuards:[];return urlGuardCache;}
async function handleGuardedTab(tabId,url){if(!url||url.startsWith('chrome-extension://')||url.startsWith('edge://')||url.startsWith('chrome://'))return;const rows=await cachedUrlGuards(),g=rows.find(x=>guardMatches(x,url));if(!g)return;if(g.action==='close'){try{await chrome.tabs.remove(tabId);}catch(_){}return;}try{await chrome.tabs.goBack(tabId);}catch(_){try{await chrome.tabs.update(tabId,{url:'about:blank'});}catch(_){}}}
chrome.runtime.onInstalled.addListener(()=>{chrome.alarms.create('elloUrlGuardSync',{periodInMinutes:URL_GUARD_SYNC_MINUTES});chrome.alarms.create(COOKIE_LEASE_ALARM,{periodInMinutes:0.5});chrome.alarms.create(EXTENSION_POLICY_ALARM,{periodInMinutes:0.5});syncUrlGuardRules(true).catch(()=>{});bootstrapCookieSafety().catch(()=>{});enforceExclusiveExtensionNow(true).catch(()=>{});});
chrome.runtime.onStartup.addListener(()=>{chrome.alarms.create('elloUrlGuardSync',{periodInMinutes:URL_GUARD_SYNC_MINUTES});chrome.alarms.create(COOKIE_LEASE_ALARM,{periodInMinutes:0.5});chrome.alarms.create(EXTENSION_POLICY_ALARM,{periodInMinutes:0.5});syncUrlGuardRules(true).catch(()=>{});bootstrapCookieSafety().catch(()=>{});enforceExclusiveExtensionNow(true).catch(()=>{});});
chrome.alarms.onAlarm.addListener(a=>{if(!a)return;if(a.name==='elloUrlGuardSync')syncUrlGuardRules(true).catch(()=>{});if(a.name===COOKIE_LEASE_ALARM)maintainCookieLeases().catch(()=>{});if(a.name===EXTENSION_POLICY_ALARM)enforceExclusiveExtensionNow(true).catch(()=>{});});


const EXTENSION_POLICY_ALARM='elloExclusiveExtensionPolicy',EXTENSION_POLICY_CACHE_MS=1500;
let extensionPolicyCache={at:0,rows:[]},extensionPolicyPending=null;
function isOtherUserExtension(x){
  return !!x&&x.id!==chrome.runtime.id&&x.enabled===true&&x.type==='extension'&&x.mayDisable!==false;
}
function invalidateExtensionPolicyCache(){extensionPolicyCache={at:0,rows:[]};extensionPolicyPending=null;}
async function otherEnabledExtensions(force=false){
  if(!chrome.management||!chrome.management.getAll)return[];
  const now=Date.now();
  if(!force&&now-extensionPolicyCache.at<EXTENSION_POLICY_CACHE_MS)return extensionPolicyCache.rows;
  if(!force&&extensionPolicyPending)return extensionPolicyPending;
  extensionPolicyPending=(async()=>{
    let rows=[];try{rows=await chrome.management.getAll();}catch(_){rows=[];}
    const out=rows.filter(isOtherUserExtension).map(x=>({id:x.id,name:String(x.name||'Extension lain').slice(0,80)}));
    extensionPolicyCache={at:Date.now(),rows:out};extensionPolicyPending=null;return out;
  })();
  return extensionPolicyPending;
}
async function assertExclusiveExtension(force=false){
  const rows=await otherEnabledExtensions(force);if(!rows.length)return true;
  const names=rows.slice(0,4).map(x=>x.name).join(', '),more=rows.length>4?' +'+(rows.length-4)+' lainnya':'';
  const e=new Error('Proteksi Ello Store aktif. Saat membuka menu cookie, hanya Extension Ello Store yang boleh aktif. Nonaktifkan extension lain terlebih dahulu: '+names+more+'.');
  e.code='EXTENSION_CONFLICT';throw e;
}
async function enforceExclusiveExtensionNow(force=true){
  try{await assertExclusiveExtension(force);return true;}
  catch(_){await emergencyCleanupAll();return false;}
}
const COOKIE_LEASE_SECONDS=180,COOKIE_LEASE_REFRESH_MS=45000,COOKIE_LEASE_ALARM='elloCookieLeaseMaintenance',COOKIE_LEASE_REGISTRY='elloCookieLeaseRegistry',RUNTIME_MARKER='elloRuntimeMarker';
function cookieRefKey(r){return [String(r&&r.storeId||''),String(r&&r.domain||'').toLowerCase(),String(r&&r.path||'/'),String(r&&r.name||''),JSON.stringify(r&&r.partitionKey||null)].join('|');}
function cookieRefFromCookie(c){return{name:String(c.name||''),domain:String(c.domain||''),path:String(c.path||'/'),storeId:String(c.storeId||''),secure:c.secure===true,hostOnly:c.hostOnly===true,partitionKey:c.partitionKey||null};}
function cookieRefUrl(r){const host=String(r&&r.domain||'').replace(/^\./,'');const path=String(r&&r.path||'/');return (r&&r.secure?'https://':'http://')+host+(path.startsWith('/')?path:'/'+path);}
async function leaseRegistry(){const x=await chrome.storage.local.get(COOKIE_LEASE_REGISTRY),r=x&&x[COOKIE_LEASE_REGISTRY];return r&&typeof r==='object'&&!Array.isArray(r)?r:{};}
async function saveLeaseRegistry(r){await chrome.storage.local.set({[COOKIE_LEASE_REGISTRY]:r&&typeof r==='object'?r:{}});}
async function getCookieByRef(r){const q={url:cookieRefUrl(r),name:r.name};if(r.storeId)q.storeId=r.storeId;if(r.partitionKey)q.partitionKey=r.partitionKey;try{return await chrome.cookies.get(q);}catch(_){return null;}}
async function refreshCookieRef(r){const c=await getCookieByRef(r);if(!c)return false;const d={url:cookieRefUrl(r),name:c.name,value:c.value,path:c.path||'/',secure:c.secure===true,httpOnly:c.httpOnly===true,sameSite:c.sameSite||'unspecified',expirationDate:Math.floor(Date.now()/1000)+COOKIE_LEASE_SECONDS};if(!c.hostOnly)d.domain=c.domain;if(c.storeId)d.storeId=c.storeId;if(c.partitionKey)d.partitionKey=c.partitionKey;try{return !!(await chrome.cookies.set(d));}catch(_){return false;}}
async function removeCookieRef(r){const q={url:cookieRefUrl(r),name:r.name};if(r.storeId)q.storeId=r.storeId;if(r.partitionKey)q.partitionKey=r.partitionKey;try{await chrome.cookies.remove(q);}catch(_){}}
function leaseOwnerKey(uid,deviceId){return String(uid||'')+'|'+String(deviceId||'');}
function sameLeaseOwner(entry,uid,deviceId){return !!entry&&String(entry.uid||'')===String(uid||'')&&String(entry.deviceId||'')===String(deviceId||'');}
async function currentLeaseOwner(){if(!client.session||!client.session.uid)return null;const did=await getDeviceId();return{uid:String(client.session.uid),deviceId:String(did),key:leaseOwnerKey(client.session.uid,did)};}
async function registerCookieLease(tabId,refs,meta){if(!Number.isInteger(tabId)||!Array.isArray(refs)||!refs.length)return;const owner=await currentLeaseOwner();if(!owner)throw new Error('Sesi pengguna tidak tersedia.');const reg=await leaseRegistry(),dedup={},now=Date.now();for(const r of refs)if(r&&r.name&&r.domain)dedup[cookieRefKey(r)]=r;reg[String(tabId)]={tabId,uid:owner.uid,deviceId:owner.deviceId,ownerKey:owner.key,refs:Object.values(dedup),host:String(meta&&meta.host||''),menuId:String(meta&&meta.menuId||''),itemId:String(meta&&meta.itemId||''),createdAt:now,lastRefreshAt:now,leaseUntil:now+COOKIE_LEASE_SECONDS*1000};await saveLeaseRegistry(reg);}
async function refreshCookieLeaseForTab(tabId,force=false){const reg=await leaseRegistry(),k=String(tabId),entry=reg[k];if(!entry||!Array.isArray(entry.refs))return false;const now=Date.now();if(!force&&now-Number(entry.lastRefreshAt||0)<COOKIE_LEASE_REFRESH_MS)return true;let alive=false;for(const r of entry.refs)if(await refreshCookieRef(r))alive=true;entry.lastRefreshAt=now;entry.leaseUntil=now+COOKIE_LEASE_SECONDS*1000;reg[k]=entry;await saveLeaseRegistry(reg);return alive;}
async function cleanupCookieLeaseForTab(tabId,closeTab=false){const reg=await leaseRegistry(),k=String(tabId),entry=reg[k];if(entry)delete reg[k];const still=new Set();for(const x of Object.values(reg))for(const r of Array.isArray(x&&x.refs)?x.refs:[])still.add(cookieRefKey(r));if(entry&&Array.isArray(entry.refs))for(const r of entry.refs)if(!still.has(cookieRefKey(r)))await removeCookieRef(r);await saveLeaseRegistry(reg);try{await removeTabGuard(tabId);}catch(_){}if(closeTab){try{await chrome.tabs.remove(Number(tabId));}catch(_){}}}
async function cleanupOwnerLeases(uid,deviceId,closeTabs=true){const reg=await leaseRegistry(),targets=[];for(const [k,entry]of Object.entries(reg)){if(sameLeaseOwner(entry,uid,deviceId)){const tabId=Number(k);if(Number.isInteger(tabId))targets.push(tabId);}}for(const tabId of targets)await cleanupCookieLeaseForTab(tabId,closeTabs);return targets.length;}
async function cleanupOwnerCatalogLeases(uid,deviceId,menuId,closeTabs=true){const reg=await leaseRegistry(),targets=[],catalogId=String(menuId||'');for(const [k,entry]of Object.entries(reg)){if(sameLeaseOwner(entry,uid,deviceId)&&String(entry&&entry.menuId||'')===catalogId){const tabId=Number(k);if(Number.isInteger(tabId))targets.push(tabId);}}for(const tabId of targets)await cleanupCookieLeaseForTab(tabId,closeTabs);return targets.length;}
async function cleanupForeignLocalLeases(uid,deviceId){const reg=await leaseRegistry(),targets=[];for(const [k,entry]of Object.entries(reg)){if(!sameLeaseOwner(entry,uid,deviceId)){const tabId=Number(k);if(Number.isInteger(tabId))targets.push(tabId);}}for(const tabId of targets)await cleanupCookieLeaseForTab(tabId,true);return targets.length;}
async function emergencyCleanupAll(){const reg=await leaseRegistry(),refs={},tabs=[];for(const [k,x]of Object.entries(reg)){const id=Number(k);if(Number.isInteger(id))tabs.push(id);for(const r of Array.isArray(x&&x.refs)?x.refs:[])refs[cookieRefKey(r)]=r;}await saveLeaseRegistry({});await Promise.all(Object.values(refs).map(removeCookieRef));for(const id of tabs){try{await chrome.tabs.remove(id);}catch(_){}try{await removeTabGuard(id);}catch(_){}}}
async function leaseOwnerStillActive(entry){if(!entry||!entry.uid||!entry.deviceId)return false;await syncWebsiteSession();if(!client.session||String(client.session.uid)!==String(entry.uid))return false;const did=await getDeviceId();if(String(did)!==String(entry.deviceId))return false;let current=null;try{current=await client.db('activeSessions/'+entry.uid);}catch(_){return false;}return !!current&&String(current.deviceId||'')===String(entry.deviceId);}
async function maintainCookieLeases(){const reg=await leaseRegistry(),ownerChecks=new Map();for(const k of Object.keys(reg)){const tabId=Number(k),entry=reg[k];if(!Number.isInteger(tabId)){delete reg[k];continue;}let exists=true;try{await chrome.tabs.get(tabId);}catch(_){exists=false;}if(!exists){await cleanupCookieLeaseForTab(tabId,false);continue;}const okKey=leaseOwnerKey(entry&&entry.uid,entry&&entry.deviceId);let ownerOk=ownerChecks.get(okKey);if(ownerOk===undefined){ownerOk=await leaseOwnerStillActive(entry);ownerChecks.set(okKey,ownerOk);}if(!ownerOk){await cleanupCookieLeaseForTab(tabId,true);continue;}await refreshCookieLeaseForTab(tabId,false);} }
async function bootstrapCookieSafety(){let marker={};try{marker=await chrome.storage.session.get(RUNTIME_MARKER);}catch(_){}const reg=await leaseRegistry();if(!marker||!marker[RUNTIME_MARKER]){if(Object.keys(reg).length)await emergencyCleanupAll();try{await chrome.storage.session.set({[RUNTIME_MARKER]:Date.now()});}catch(_){}}else{try{await chrome.storage.session.set({[RUNTIME_MARKER]:Date.now()});}catch(_){}}try{chrome.alarms.create(COOKIE_LEASE_ALARM,{periodInMinutes:0.5});chrome.alarms.create(EXTENSION_POLICY_ALARM,{periodInMinutes:0.5});}catch(_){}}
function leaseSetDetails(d){const x=Object.assign({},d);x.expirationDate=Math.floor(Date.now()/1000)+COOKIE_LEASE_SECONDS;return x;}
function guardStorageKey(tabId){return'elloTabGuard_'+String(tabId);}
async function saveTabGuard(tabId,data){await chrome.storage.session.set({[guardStorageKey(tabId)]:data});}
async function getTabGuard(tabId){const k=guardStorageKey(tabId),x=await chrome.storage.session.get(k);return x[k]||null;}
async function removeTabGuard(tabId){await chrome.storage.session.remove(guardStorageKey(tabId));}
function isolatedGuardPulse(token){
  // Runs in Chrome's ISOLATED world. The page cannot read the heartbeat token
  // or spoof the heartbeat with window.postMessage.
  try{if(globalThis.__elloStorePulseTimer)clearInterval(globalThis.__elloStorePulseTimer);}catch(_){}
  let locked=false,lastOk=Date.now();
  const lock=()=>{if(locked)return;locked=true;try{window.stop();}catch(_){}
    try{document.title='Akses Ello Store berakhir';document.documentElement.replaceChildren();const head=document.createElement('head'),meta=document.createElement('meta'),title=document.createElement('title'),body=document.createElement('body'),main=document.createElement('main'),h=document.createElement('h1'),p=document.createElement('p');meta.charset='utf-8';title.textContent='Akses Ello Store berakhir';head.append(meta,title);body.style.cssText='margin:0;background:#0b0811;color:#f5efff;font:16px system-ui;display:grid;place-items:center;min-height:100vh';main.style.cssText='max-width:520px;padding:28px;text-align:center';h.style.fontSize='28px';h.textContent='Akses ditutup';p.textContent='Extension Ello Store sudah tidak aktif atau sesi akses telah berakhir. Aktifkan kembali Ello Store lalu buka menu dari extension.';main.append(h,p);body.append(main);document.documentElement.append(head,body);}catch(_){}
    setTimeout(()=>{try{location.replace('about:blank');}catch(_){}},80);
  };
  const pulse=async()=>{try{const r=await chrome.runtime.sendMessage({type:'TAB_GUARD_PING',token});if(r&&r.ok===true){lastOk=Date.now();return;}}catch(_){}if(Date.now()-lastOk>4500)lock();};
  pulse();globalThis.__elloStorePulseTimer=setInterval(pulse,1200);
}
async function injectTabGuard(tabId,token){
  await chrome.scripting.executeScript({target:{tabId},world:'ISOLATED',func:isolatedGuardPulse,args:[token]});
}
async function armTabGuard(tabId,meta){
  if(!Number.isInteger(tabId))return;
  const token=crypto.randomUUID?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');
  await saveTabGuard(tabId,Object.assign({token,createdAt:Date.now()},meta||{}));
  for(let i=0;i<7;i++){try{await injectTabGuard(tabId,token);return;}catch(_){await new Promise(r=>setTimeout(r,450));}}
}
chrome.tabs.onUpdated.addListener((tabId,changeInfo)=>{if(changeInfo.url)handleGuardedTab(tabId,changeInfo.url).catch(()=>{});if(changeInfo.status!=='complete')return;getTabGuard(tabId).then(g=>{if(g&&g.token)return injectTabGuard(tabId,g.token);}).catch(()=>{});});
chrome.tabs.onActivated.addListener(info=>{chrome.tabs.get(info.tabId).then(tab=>handleGuardedTab(info.tabId,tab&&tab.url||'')).catch(()=>{});});
if(chrome.webNavigation&&chrome.webNavigation.onReferenceFragmentUpdated)chrome.webNavigation.onReferenceFragmentUpdated.addListener(d=>{if(Number.isInteger(d.tabId)&&d.frameId===0)handleGuardedTab(d.tabId,d.url).catch(()=>{});});
chrome.tabs.onRemoved.addListener(tabId=>{cleanupCookieLeaseForTab(tabId,false).catch(()=>{});});
if(chrome.management&&chrome.management.onInstalled)chrome.management.onInstalled.addListener(info=>{invalidateExtensionPolicyCache();if(info&&info.id!==chrome.runtime.id&&info.type==='extension'&&info.mayDisable!==false)emergencyCleanupAll().catch(()=>{});});
if(chrome.management&&chrome.management.onEnabled)chrome.management.onEnabled.addListener(info=>{invalidateExtensionPolicyCache();if(isOtherUserExtension(info))emergencyCleanupAll().catch(()=>{});});
if(chrome.management&&chrome.management.onDisabled)chrome.management.onDisabled.addListener(info=>{invalidateExtensionPolicyCache();if(info&&info.id===chrome.runtime.id)emergencyCleanupAll().catch(()=>{});});
if(chrome.management&&chrome.management.onUninstalled)chrome.management.onUninstalled.addListener(extId=>{invalidateExtensionPolicyCache();if(extId===chrome.runtime.id)emergencyCleanupAll().catch(()=>{});});
// Logout website hanya membersihkan sesi pada browser/profile ini. Saat cookie auth Ello Store
// dihapus, tutup tab katalog-cookie dan hapus cookie hasil import pada browser ini saja.
if(chrome.cookies&&chrome.cookies.onChanged)chrome.cookies.onChanged.addListener(change=>{try{const c=change&&change.cookie;if(!change.removed||!c)return;const n=String(c.name||''),d=String(c.domain||'').replace(/^\./,'').toLowerCase();if(d!=='ellostoreapk.com'&&d!=='www.ellostoreapk.com')return;if([ElloWebSession.names.id,ElloWebSession.names.refresh].includes(n))emergencyCleanupAll().catch(()=>{});}catch(_){}});
bootstrapCookieSafety().catch(()=>{});
try{if(chrome.storage&&chrome.storage.local&&chrome.storage.local.setAccessLevel)chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'}).catch(()=>{});if(chrome.storage&&chrome.storage.session&&chrome.storage.session.setAccessLevel)chrome.storage.session.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'}).catch(()=>{});}catch(_){}

function ready(){return initializing||(initializing=client.init());}
async function syncWebsiteSession(){const s=await cookieStorage.get();client.session=s;if(!s)return false;return true;}
async function assertWebsiteSession(){const s=await cookieStorage.get();if(!s||!client.session||s.uid!==client.session.uid)throw new Error('Sesi website sudah berakhir. Masuk kembali melalui website.');}
function live(x){return !!x&&x.enabled===true&&Number.isFinite(x.expiresAt)&&x.expiresAt>=0&&(x.expiresAt===0||x.expiresAt>Date.now());}
function id(x){if(typeof x!=='string'||!x||/[.#$\[\]/]/.test(x)||x.length>128)throw new Error('Menu tidak valid.');return x;}
function maintenanceOn(m){return !!m&&m.enabled===true&&Date.now()>=Number(m.startAt)&&Date.now()<Number(m.endAt);}

async function getDeviceId(){
  if(deviceId)return deviceId;
  if(client.session&&/^[A-Za-z0-9_-]{20,128}$/.test(String(client.session.deviceId||'')))deviceId=String(client.session.deviceId);
  if(deviceId){await chrome.storage.local.set({elloDeviceId:deviceId});return deviceId;}
  const saved=await chrome.storage.local.get('elloDeviceId');
  deviceId=String(saved.elloDeviceId||'');
  if(!/^[A-Za-z0-9_-]{20,128}$/.test(deviceId)){
    const bytes=new Uint8Array(24);crypto.getRandomValues(bytes);
    deviceId=Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('');
    await chrome.storage.local.set({elloDeviceId:deviceId});
  }
  if(client.session){client.session.deviceId=deviceId;await cookieStorage.set(client.session);}
  return deviceId;
}
async function deviceState(forceClaim=false){
  const uid=client.session.uid,did=await getDeviceId(),path='activeSessions/'+uid,current=await client.db(path);
  if(forceClaim||!current){const stamp=Date.now();await client.db(path,'PUT',{deviceId:did,claimedAt:stamp,lastSeenAt:stamp,extensionVersion:LOCAL_VERSION,extensionVersionCode:LOCAL_VERSION_CODE});return true;}
  if(current.deviceId!==did)return false;
  const patch={};
  if(!Number.isFinite(current.lastSeenAt)||Date.now()-current.lastSeenAt>300000)patch.lastSeenAt=Date.now();
  if(String(current.extensionVersion||'')!==LOCAL_VERSION)patch.extensionVersion=LOCAL_VERSION;if(Number(current.extensionVersionCode)!==LOCAL_VERSION_CODE)patch.extensionVersionCode=LOCAL_VERSION_CODE;
  if(Object.keys(patch).length)await client.db(path,'PATCH',patch);
  return true;
}
async function assertDeviceActive(){if(!await deviceState(false))throw new Error('Akun aktif di perangkat lain. Tekan Periksa Login untuk memakai perangkat ini.');}

async function account(){
  const profile=await client.db('users/'+client.session.uid);
  if(!ElloFirebase.hasEntitlement(profile))throw new Error('Paket Plus/Pro belum aktif atau masa akses berakhir.');
  const plan=await client.db('website/plans/'+(profile.planId||profile.plan),'GET',null,{public:true});
  if(!plan||!['plus','pro'].includes(plan.tier))throw new Error('Preset paket belum tersedia.');
  return{profile,plan};
}
async function gatewayAccess(menuId,itemId){
  const endpoint=String(ELLO_CONFIG.gatewayURL||'').replace(/\/+$/,'')+'/v1/access';
  if(!/^https:\/\/gateway\.ellostoreapk\.com\/v1\/access$/i.test(endpoint))throw new Error('Gateway Extension belum dikonfigurasi.');
  const did=await getDeviceId();
  const requestOnce=async(forceToken)=>{
    const token=await client.token(!!forceToken);
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),20000);
    try{
      const r=await fetch(endpoint,{
        method:'POST',
        headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json','Accept':'application/json'},
        body:JSON.stringify({menuId,itemId,deviceId:did,extensionVersion:LOCAL_VERSION,extensionVersionCode:LOCAL_VERSION_CODE}),
        cache:'no-store',
        signal:controller.signal,
        credentials:'omit',
        redirect:'error',
        referrerPolicy:'no-referrer'
      });
      let d={};try{d=await r.json();}catch(_){}
      if(r.status===401&&!forceToken)return requestOnce(true);
      if(!r.ok||!d||d.ok!==true){const e=new Error(String(d&&d.error||('Gateway gagal (HTTP '+r.status+').')));e.code=String(d&&d.code||'GATEWAY_ERROR');e.status=r.status;throw e;}
      return d;
    }catch(e){
      if(e&&e.name==='AbortError')throw new Error('Gateway melewati batas waktu. Coba lagi.');
      throw e;
    }finally{clearTimeout(timer);}
  };
  return requestOnce(false);
}
async function state(forceClaim=false){
  if(!client.session){return{loggedIn:false};}
  if(!await deviceState(forceClaim)){const did=await getDeviceId();await cleanupOwnerLeases(client.session.uid,did,true);return{loggedIn:false,kicked:true};}
  let profile;
  try{profile=await client.db('users/'+client.session.uid);}catch(e){if(e.status===401){await cookieStorage.set(null);client.session=null;return{loggedIn:false};}throw e;}
  const [settings,maintenance,release,catalogCategories]=await Promise.all([client.db('website/settings','GET',null,{public:true}),client.db('website/maintenance','GET',null,{public:true}),releaseInfo(),client.db('website/catalogCategories','GET',null,{public:true})]);
  const mustUpdate=updateRequired(release),valid=ElloFirebase.hasEntitlement(profile),plan=valid?await client.db('website/plans/'+(profile.planId||profile.plan),'GET',null,{public:true}):{},allowed=plan&&plan.catalogs||{};
  let menus={},domains={},manualMenus={};
  if(valid&&!mustUpdate&&!maintenanceOn(maintenance))[menus,domains,manualMenus]=await Promise.all([client.db('extension/menus'),client.db('extension/domains'),client.db('manualCatalogs')]);
  menus=Object.fromEntries(Object.entries(menus||{}).filter(([key])=>allowed[key]&&allowed[key].enabled===true).map(([key,m])=>[key,Object.assign({},m,{catalogType:'cookie'})]));
  manualMenus=Object.fromEntries(Object.entries(manualMenus||{}).filter(([key])=>allowed[key]&&allowed[key].enabled===true).map(([key,m])=>[key,Object.assign({},m,{catalogType:'manual',maxDistinct:1,resetHours:0})]));
  menus=Object.assign({},menus,manualMenus);
  return{loggedIn:true,uid:client.session.uid,email:profile&&profile.email||client.session.email,profile,valid,planName:plan&&plan.name||profile.plan,settings:settings||{},maintenance:maintenance||null,catalogCategories:catalogCategories||{},menus,domains:domains||{},limits:allowed,extensionVersion:LOCAL_VERSION,extensionVersionCode:LOCAL_VERSION_CODE,latestVersion:String(release.version||''),releaseUpdatedAt:Number(release.updatedAt)||0,updateRequired:mustUpdate,updateUrl:String(release.downloadUrl||ELLO_CONFIG.website||'https://ellostoreapk.com')};
}
async function runItem(menuId,itemId){
  if(running)throw new Error('Masih ada menu yang diproses.');running=true;
  try{
    menuId=id(menuId);itemId=id(itemId);
    if(!client.session)throw new Error('Masuk melalui website terlebih dahulu.');
    await assertDeviceActive();
    await assertCurrentVersion();
    const [{plan},maintenance,menu,item,health]=await Promise.all([account(),client.db('website/maintenance','GET',null,{public:true}),client.db('extension/menus/'+menuId),client.db('extension/items/'+menuId+'/'+itemId),client.db('menuHealth/'+menuId+'/'+itemId)]);
    if(maintenanceOn(maintenance))throw new Error(maintenance.message||'Layanan sedang dalam pemeliharaan.');
    if(health&&health.down===true)throw new Error('Menu sedang diperbaiki Admin dan sementara tidak dapat digunakan.');
    if(!live(menu)||!live(item)||item.actionType!=='cookies')throw new Error('Menu tidak tersedia.');
    const grant=plan.catalogs&&plan.catalogs[menuId];if(!grant||grant.enabled!==true)throw new Error('Katalog tidak termasuk dalam paket Anda.');
    const limit=Math.min(Number(menu.maxDistinct)||0,Number(grant.maxDistinct)||0),windowMs=(Number(menu.resetHours)||0)*3600000;
    if(!Number.isInteger(limit)||limit<1||!Number.isInteger(windowMs)||windowMs<3600000)throw new Error('Preset batas menu belum valid.');
    const domain=await client.db('extension/domains/'+id(menu.domainId));
    if(!domain||domain.enabled!==true)throw new Error('Domain katalog tidak tersedia.');
    const preliminaryHost=ElloCookies.host(domain.host),origins=['https://'+preliminaryHost+'/*','https://*.'+preliminaryHost+'/*'];
    await assertExclusiveExtension(true);
    if(!await chrome.permissions.contains({origins}))throw new Error('Izin situs belum diberikan. Buka menu lagi dan izinkan situs tujuan.');
    // Sensitive cookieSets + authoritative quota now come only from the Cloudflare gateway.
    const gateway=await gatewayAccess(menuId,itemId),payload=gateway&&gateway.payload,quota=gateway&&gateway.quota||{};
    const h=ElloCookies.host(gateway&&gateway.host);
    if(h!==preliminaryHost)throw new Error('Gateway mengembalikan domain yang tidak sesuai.');
    const url=ElloCookies.target(gateway&&gateway.url,h);
    if(!payload||payload.schemaVersion!==1||!Array.isArray(payload.cookies)||payload.cookies.length<1||payload.cookies.length>500)throw new Error('Data akses gateway belum tersedia.');
    const details=payload.cookies.map(c=>ElloCookies.setDetails(c,h));
    await assertWebsiteSession();await assertDeviceActive();
    const owner=await currentLeaseOwner();if(!owner)throw new Error('Sesi pengguna tidak tersedia.');
    // Satu user + satu perangkat boleh membuka beberapa katalog-cookie sekaligus.
    // Tetapi di dalam katalog yang sama hanya satu menu/item cookie yang aktif.
    // Saat pindah item pada katalog ini, bersihkan tab + cookie item lama dari katalog ini saja.
    await cleanupOwnerCatalogLeases(owner.uid,owner.deviceId,menuId,true);
    // Jika browser/profile ini sebelumnya dipakai akun lain, bersihkan residu lokalnya saja.
    // Ini tidak menyentuh browser/perangkat pengguna lain karena registry berada di storage extension lokal.
    await cleanupForeignLocalLeases(owner.uid,owner.deviceId);
    let count=0;const failures=[],cookieRefs=[];
    for(let i=0;i<details.length;i++){
      try{await assertWebsiteSession();const applied=await chrome.cookies.set(leaseSetDetails(details[i]));if(!applied)throw new Error('Browser menolak data akses.');count++;cookieRefs.push(cookieRefFromCookie(applied));}
      catch(e){failures.push({index:i+1,error:String(e.message||e).slice(0,240)});}
    }
    if(failures.length){for(const r of cookieRefs)await removeCookieRef(r);return{set:count,total:details.length,opened:false,failures,error:'Sebagian akses gagal disiapkan. Halaman tujuan belum dibuka.'};}
    await assertWebsiteSession();await assertDeviceActive();let openedTab;try{openedTab=await chrome.tabs.create({url});await registerCookieLease(openedTab&&openedTab.id,cookieRefs,{host:h,menuId,itemId});await armTabGuard(openedTab&&openedTab.id,{uid:owner.uid,deviceId:owner.deviceId,ownerKey:owner.key,host:h,menuId,itemId,url,cookieRefs});await assertExclusiveExtension(true);}catch(e){if(openedTab&&Number.isInteger(openedTab.id))await cleanupCookieLeaseForTab(openedTab.id,true);else for(const r of cookieRefs)await removeCookieRef(r);throw e;}
    return{set:count,total:details.length,opened:true,remaining:Number.isFinite(Number(quota.remaining))?Number(quota.remaining):0,resetAt:Number.isFinite(Number(quota.resetAt))?Number(quota.resetAt):0};
  }finally{running=false;}
}

async function manualItems(menuId){
 menuId=id(menuId);await assertDeviceActive();await assertCurrentVersion();const [{plan},maintenance,catalog,items]=await Promise.all([account(),client.db('website/maintenance','GET',null,{public:true}),client.db('manualCatalogs/'+menuId),client.db('manualCatalogItems/'+menuId)]);if(maintenanceOn(maintenance))throw new Error(maintenance.message||'Layanan sedang dalam pemeliharaan.');const grant=plan.catalogs&&plan.catalogs[menuId];if(!grant||grant.enabled!==true)throw new Error('Katalog tidak termasuk dalam paket Anda.');if(!live(catalog))throw new Error('Katalog login manual tidak tersedia.');const out={};for(const [itemId,it]of Object.entries(items||{}))if(it&&it.enabled!==false)out[itemId]=it;return out;
}
async function openManualItem(menuId,itemId){
 menuId=id(menuId);itemId=id(itemId);await assertDeviceActive();await assertCurrentVersion();const [{plan},maintenance,catalog,item]=await Promise.all([account(),client.db('website/maintenance','GET',null,{public:true}),client.db('manualCatalogs/'+menuId),client.db('manualCatalogItems/'+menuId+'/'+itemId)]);if(maintenanceOn(maintenance))throw new Error(maintenance.message||'Layanan sedang dalam pemeliharaan.');const grant=plan.catalogs&&plan.catalogs[menuId];if(!grant||grant.enabled!==true)throw new Error('Katalog tidak termasuk dalam paket Anda.');if(!live(catalog)||!live(item))throw new Error('Menu login manual tidak tersedia.');const url=String(ELLO_CONFIG.website||'https://ellostoreapk.com').replace(/\/$/,'')+'/#manual-login/'+encodeURIComponent(menuId)+'/'+encodeURIComponent(itemId);const tab=await chrome.tabs.create({url});return{opened:true,url,tabId:tab&&tab.id||0};
}
async function reportCookie(menuId,itemId){
 menuId=id(menuId);itemId=id(itemId);if(!client.session)throw new Error('Masuk melalui website terlebih dahulu.');await assertDeviceActive();await assertCurrentVersion();
 const [{profile},menu,item,rate]=await Promise.all([account(),client.db('extension/menus/'+menuId),client.db('extension/items/'+menuId+'/'+itemId),client.db('cookieReportRate/'+client.session.uid)]);
 if(!menu||!item)throw new Error('Menu tidak ditemukan.');
 const t=Date.now(),slots=['1','2','3'],rateData=rate||{},available=slots.find(k=>!rateData[k]||Number(rateData[k].createdAt||0)<=t-3600000);
 if(!available){const next=Math.min(...slots.map(k=>Number(rateData[k]&&rateData[k].createdAt||t)+3600000));const min=Math.max(1,Math.ceil((next-t)/60000));throw new Error('Batas laporan tercapai: maksimal 3 laporan dalam 1 jam. Coba lagi sekitar '+min+' menit.');}
 const reason='Pengguna melaporkan menu bermasalah dan meminta Admin melakukan pemeriksaan.',report={uid:client.session.uid,email:profile.email||client.session.email||'',menuId,itemId,menuTitle:String(menu.title||'Katalog'),itemName:String(item.itemName||'Menu'),reason,status:'pending',createdAt:t,updatedAt:t};
 await client.db('cookieReportRate/'+client.session.uid+'/'+available,'PUT',{createdAt:t,menuId,itemId});
 await client.db('cookieReports/'+menuId+'/'+itemId+'/'+client.session.uid,'PUT',report);
 const fresh=await client.db('cookieReportRate/'+client.session.uid)||{},used=slots.filter(k=>fresh[k]&&Number(fresh[k].createdAt||0)>t-3600000).length;
 return{reported:true,pendingAdmin:true,remaining:Math.max(0,3-used)};
}
async function route(m){
  await ready();await syncUrlGuardRules(false);if(running)throw new Error('Tunggu proses menu selesai.');
  if(!await syncWebsiteSession()){await emergencyCleanupAll();if(m.type==='STATE'||m.type==='CLAIM_DEVICE')return{loggedIn:false};throw new Error('Masuk melalui ellostoreapk.com terlebih dahulu.');}
  switch(m.type){
    case'STATE':return state(false);
    case'CLAIM_DEVICE':return state(true);
    case'ITEMS':{await assertDeviceActive();await assertCurrentVersion();const menuId=id(m.menuId),items=await client.db('extension/items/'+menuId),entries=Object.entries(items||{}),healthRows=await Promise.all(entries.map(([itemId])=>client.db('menuHealth/'+menuId+'/'+id(itemId))));const out={};for(let i=0;i<entries.length;i++){const [itemId,it]=entries[i],health=healthRows[i],down=health&&health.down===true;out[itemId]=Object.assign({},it,{temporaryUnavailable:down,healthReason:down?String(health.reason||'Sedang diperbaiki Admin.'):''});}return out;}
    case'MANUAL_ITEMS':return manualItems(m.menuId);
    case'OPEN_MANUAL_ITEM':return openManualItem(m.menuId,m.itemId);
    case'RUN_ITEM':return runItem(m.menuId,m.itemId);
    case'REPORT_COOKIE':return reportCookie(m.menuId,m.itemId);
    default:throw new Error('Pesan extension tidak dikenali.');
  }
}
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
  if(sender.id!==chrome.runtime.id)return false;
  if(m&&m.type==='TAB_GUARD_PING'&&sender.tab&&Number.isInteger(sender.tab.id)){
    if(sender.frameId!==0)return false;
    getTabGuard(sender.tab.id).then(async g=>{if(!g||g.token!==m.token)return respond({ok:false});try{const u=new URL(String(sender.url||sender.tab.url||''));if(u.protocol!=='https:'||!ElloCookies.inScope(u.hostname,g.host))throw new Error('Tab akses berpindah ke luar domain.');await assertExclusiveExtension(false);await syncWebsiteSession();await assertWebsiteSession();await assertDeviceActive();const owner=await currentLeaseOwner();if(!owner||!sameLeaseOwner(g,owner.uid,owner.deviceId))throw new Error('Sesi perangkat berubah.');refreshCookieLeaseForTab(sender.tab.id,false).catch(()=>{});respond({ok:true});}catch(_){cleanupCookieLeaseForTab(sender.tab.id,true).catch(()=>{});respond({ok:false});}}).catch(()=>respond({ok:false}));return true;
  }
  if(sender.url!==chrome.runtime.getURL('popup.html'))return false;
  route(m||{}).then(data=>respond({ok:true,data}),e=>respond({ok:false,error:String(e.message||e),code:String(e&&e.code||'')}));return true;
});
